<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include "conexao.php";

$_POST = json_decode(file_get_contents('php://input'), true);
mysqli_query($con, "SET NAMES 'utf8'");

$perguntas = $_POST['perguntas'];
$usuarioid = $_POST['usuarioid'];

foreach ($perguntas as $keyP => $valorP) {
    $quizperguntaid = $valorP['id'];
    $respostas = $valorP['respostas'];

    foreach ($respostas as $key => $valor) {
        $resposta = $valor['resposta'];
        $idresposta = $valor['id'];

        if ($idresposta == '') {
            if ($valorP['tiporesposta'] == "MULTIPLAESCOLHA") {
                if (!$resposta) {
                    continue;
                }
                $resposta = $key;
            }
            $sql = "INSERT INTO quizresposta(quizperguntaid,usuarioid,resposta) values ('$quizperguntaid','$usuarioid','$resposta')";
            $consulta = mysqli_query($con, $sql);
            if ($consulta) {
                $sql1 = "SELECT * FROM quizresposta WHERE id = LAST_INSERT_ID()";
                $consulta = mysqli_query($con, $sql1);
                $resultado = mysqli_fetch_assoc($consulta);
                $valorP['respostas'][$key]['id'] = $resultado["id"];

                $retorno = array('success' => true, 'message' => 'Resposta cadastrada com sucesso.', 'item' => $_POST);
            } else {
                $retorno = array('success' => false, 'message' => "Erro ao salvar resposta. #1. Erro:" . mysqli_error($con));
            }

        } else {
            if (($valorP['tiporesposta'] == "MULTIPLAESCOLHA") && (!$resposta)) {
                $sql = "DELETE FROM quizresposta WHERE id = '$idresposta'";
                $consulta = mysqli_query($con, $sql);
                if ($consulta) {
                    $retorno = array('success' => true, 'message' => 'Resposta cadastrada com sucesso.', 'item' => $_POST);
                } else {
                    $retorno = array('success' => false, 'message' => "Erro ao deletar resposta. #3 Erro:" . mysqli_error($con));
                }
            } else {
                if ($valorP['tiporesposta'] == "MULTIPLAESCOLHA") {
                    $resposta = $key;
                }
                    $sql = "UPDATE quizresposta SET resposta='$resposta' WHERE id = '$idresposta'";
                $consulta = mysqli_query($con, $sql);
                if ($consulta) {
                    $retorno = array('success' => true, 'message' => 'Resposta alterado com sucesso.', 'item' => $_POST);
                } else {
                    $retorno = array('success' => false, 'message' => "Erro ao salvar resposta. #2. Erro:" . mysqli_error($con));
                }
            }

        }
        if (!$retorno['success']) {
            break;
        }

    }
    if (!$retorno['success']) {
        break;
    }

}

$retorno['item']['respondido'] = true;

echo json_encode($retorno);

mysqli_close($con);

?>