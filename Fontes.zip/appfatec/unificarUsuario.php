<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("conexao.php");

$_POST = json_decode(file_get_contents('php://input'), true);

$idusermanter = $_POST["idusermanter"];
$iduserapagar = $_POST["iduserapagar"];

if(($idusermanter === null) || ($idusermanter === "")){
    $retorno = array('success' => false,'message'=>'Usuário a manter não foi informado.');
    echo json_encode($retorno);
    return;
}

if(($iduserapagar === null) || ($iduserapagar === "")){
    $retorno = array('success' => false,'message'=>'Usuário a manter não foi informado.');
    echo json_encode($retorno);
    return;
}

$sql = "UPDATE post SET iduser = $idusermanter WHERE iduser = $iduserapagar";
$consulta = mysqli_query($con, $sql);
if (!$consulta) {
    $retorno = array('success' => false, 'message' => "Erro ao alterar registro. #1. Erro:" . mysqli_error($con));
    echo json_encode($retorno);
    return;
}

mysqli_close($con);

$retorno = array('success' => true, 'message' => 'Registros alterados com sucesso.');
echo json_encode($retorno);

?>