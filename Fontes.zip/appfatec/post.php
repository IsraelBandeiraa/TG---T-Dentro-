<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("conexao.php");

$_POST = json_decode(file_get_contents('php://input'), true);
mysqli_query($con, "SET NAMES 'utf8'"); 
mysqli_query($con, "SET CHARACTER SET 'utf8'");

// $inicio = $_POST["inicio"];
// $fim = $_POST["fim"];

$query = "select pessoa.id,pessoa.nome as nome, pessoa.imagem as foto, 
post.data, post.titulo, post.texto, post.imagem as imagem, post.id as postid, 
COALESCE((SELECT count(id) FROM postcurtida where postcurtida.idpost = post.id),0) as curtiu 
from post
JOIN pessoa on pessoa.id = post.iduser where post.aprovado = 1
order by post.id desc"; //limit $inicio, $fim
$sql= mysqli_query($con, $query);
$data = array();
while ($result =  mysqli_fetch_array($sql, MYSQLI_ASSOC))
{
//echo $result['id'];
    $json = array(
        'id' => $result['id'], 
        'nome' => $result['nome'], 
        'foto' => $result['foto'], 
        'data' => $result['data'],
        'titulo' => $result['titulo'],
        'texto' => $result['texto'],
        'empresa' => $result['empresa'],
        'imagem' => $result['imagem'],
        'postid' => $result['postid'],
        'curtiu' => $result["curtiu"]
    );
//echo json_encode($json);
    array_push($data, $json);
}
mysqli_close($con);
//echo "fim";
echo json_encode($data);


?>