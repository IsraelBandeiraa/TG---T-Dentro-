<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("conexao.php");

$_POST = json_decode(file_get_contents('php://input'), true);

$query = "SELECT e.id,e.nome,e.status,e.lide,e.lidefuturo,e.lidemulher FROM empresa e ORDER BY nome";

$sql= mysqli_query($con, $query);
$data = array();
while ($result =  mysqli_fetch_array($sql, MYSQLI_ASSOC))
{

	array_push($data, array(
		'id' => $result['id'], 
		'nome' => $result['nome'], 
		'status' => $result['status'],
		'lide' => $result['lide'],
		'lidefuturo' => $result['lidefuturo'],
		'lidemulher' => $result['lidemulher']
	));

}

mysqli_close($con);

echo json_encode($data);

?>