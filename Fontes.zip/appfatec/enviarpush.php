<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$_POST = json_decode(file_get_contents('php://input'), true);

$destinatario = $_POST["destinatario"];
$titulo = $_POST["titulo"];
$texto = $_POST["texto"];

if(($destinatario === null) || ($destinatario === "")){
    $retorno = array('success' => false,'message'=>'Destinatário não foi definido.');
    echo json_encode($retorno);
    return;
}

if(($titulo === null) || ($titulo === "")){
    $retorno = array('success' => false,'message'=>'Titulo foi definido.');
    echo json_encode($retorno);
    return;
}

if(($texto === null) || ($texto === "")){
    $retorno = array('success' => false,'message'=>'Mensagem não foi definido.');
    echo json_encode($retorno);
    return;
}

include("notificacao.php");
include("conexao.php");

$retorno = enviarNotificacao($con,"PERSONALIZADA","","",$_POST);

echo json_encode($retorno);

mysqli_close($con);



?>