<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include "conexao.php";
include "imagem.php";

$url = full_url($_SERVER);

$_POST = json_decode(file_get_contents('php://input'), true);
mysqli_query($con, "SET NAMES 'utf8'");
mysqli_query($con, "SET CHARACTER SET 'utf8'");
$id = $_POST["id"];
$query = "SELECT id, nome, email, cargo, empresa, lide, lidefuturo, lidemulher, imagem from pessoa
 where id in(select idcontato from contato where userid = $id and aceito = 1) or
id in (select userid from contato where idcontato = $id and aceito = 1)";
$sql = mysqli_query($con, $query);
$data = array();
while ($result = mysqli_fetch_array($sql, MYSQLI_ASSOC)) {

    $consulta = "select favorito from contato where idcontato = " . $result["id"] . " and solicitante = $id or idcontato = $id and solicitante = " . $result["id"] . "";
    $trem = mysqli_query($con, $consulta);
    $res = mysqli_fetch_assoc($trem);

    $imagem = $result['imagem'];
    if (!(substr($imagem, 0, 10) == "data:image")) {
        $imagem = $url . $imagem;
    }

    array_push($data, array(
        'id' => $result['id'],
        'nome' => $result['nome'],
        'email' => $result['email'],
        'cargo' => $result['cargo'],
        'empresa' => $result['empresa'],
        'lide' => $result['lide'],
        'lidefuturo' => $result['lidefuturo'],
        'lidemulher' => $result['lidemulher'],
        'imagem' => $imagem,
        'favorito' => $res['favorito'],
    ));

}

echo json_encode($data);

mysqli_close($con);
