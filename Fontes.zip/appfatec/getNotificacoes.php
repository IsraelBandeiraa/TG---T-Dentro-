<?php
header("Access-Control-Allow-Origin: *");
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

include "conexao.php";
$_POST = json_decode(file_get_contents('php://input'), true);
$id = $_POST["id"];

$query = "SELECT nu.id,nu.tipo,nu.objetoid,nu.entregue,nu.lido,n.jsoncorpo,n.datahora FROM notificacaousuario nu, notificacao n WHERE nu.notificacaoid = n.id AND userid = '$id' ORDER BY datahora DESC";
$sql = mysqli_query($con, $query);
$notificacoes = array();
while ($result = mysqli_fetch_array($sql, MYSQLI_ASSOC)) {
    $json = $result['jsoncorpo'];
    $json = str_replace(array("\n","\r"),"  ",$json); 
    array_push($notificacoes, array("id" => $result['id'],
        "tipo" => $result['tipo'],
        "objetoid" => intval($result['objetoid']),
        "entregue" => intval($result['entregue']),
        "lido" => intval($result['lido']),
        "jsoncorpo" => json_decode(utf8_encode($json), true),
        "datahora" => $result['datahora'],
    )
    );
}

echo json_encode($notificacoes);

?>