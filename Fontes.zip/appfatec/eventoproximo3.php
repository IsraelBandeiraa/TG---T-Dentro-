<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include "conexao.php";

mysqli_query($con, "SET NAMES 'utf8'");
mysqli_query($con, "SET CHARACTER SET 'utf8'");
$lide = $_GET["lide"];
$lidefuturo = $_GET["lidefuturo"];
$lidemulher = $_GET["lidemulher"];

$filiacao = "";
if ($lide == 1) {
	$filiacao = ($filiacao != "") ? $filiacao . " OR " : "";
	$filiacao = $filiacao . " lide = 1 ";
}
if ($lidefuturo == 1) {
	$filiacao = ($filiacao != "") ? $filiacao . " OR " : "";
	$filiacao = $filiacao . " lidefuturo = 1 ";
}
if ($lidemulher == 1) {
	$filiacao = ($filiacao != "") ? $filiacao . " OR " : "";
	$filiacao = $filiacao . " lidemulher = 1 ";
}

if ($lide == 1 || $lidefuturo == 1 || $lidemulher == 1) {
    $query = "SELECT * FROM evento WHERE status = 1 AND data >= CURRENT_DATE() AND ($filiacao) order by data asc";
} else {
    $query = "SELECT * FROM evento WHERE status = 1 AND data >= CURRENT_DATE() AND lidefuturo = 0 AND lide = 0 AND lidemulher = 0 order by data asc";
}

$sql = mysqli_query($con, $query);
$data = array();
while ($result = mysqli_fetch_array($sql, MYSQLI_ASSOC)) {
    array_push($data, array('id' => $result['id'],
        'nome' => $result['nome'],
        'imagem' => $result['imagem'],
        'endereco' => $result['endereco'],
        'status' => $result['status'],
        'data' => $result['data'],
        'lat' => $result['latitude'],
        'long' => $result['longitude'],
        'lide' => $result['lide'],
        'lidefuturo' => $result['lidefuturo'],
        'lidemulher' => $result['lidemulher'],
        'descricao' => nl2br($result['descricao'])));

}
echo json_encode($data);

mysqli_close($con);
