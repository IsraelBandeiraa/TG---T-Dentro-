<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$_POST = json_decode(file_get_contents('php://input'), true);
include("conexao.php");
   
$idPergunta = $_POST["idPergunta"];

$sql = "UPDATE chatevento SET lido = 1 WHERE id = $idPergunta";

mysqli_query($con, $sql);

mysqli_close($con);

echo '{"status":"OK"}';


?>