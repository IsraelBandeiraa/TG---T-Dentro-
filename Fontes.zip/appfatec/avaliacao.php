
<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include "conexao.php";

$_POST = json_decode(file_get_contents('php://input'), true);
mysqli_query($con, "SET NAMES 'utf8'");

$idevento = $_POST['idevento'];
$idusuario = $_POST['idusuario'];

$sql = "UPDATE notificacaousuario SET lido = 1 WHERE tipo IN ('AVALIAREVENTO') AND userid = $idusuario AND objetoid = $idevento";
$consulta = mysqli_query($con, $sql);
if ($consulta) {
    $retorno = array('success' => true, 'message' => 'Notificações marcadas como lida.');
} else {
    $retorno = array('success' => false, 'message' => 'Erro ao marcar notificações como lida. #1');
}


$query = "SELECT e.id,e.nome,e.imagem,ea.nota,ea.comentario FROM evento e LEFT JOIN eventoavaliacao ea ON e.id = ea.eventoid AND ea.usuarioid = '$idusuario' WHERE e.id = '$idevento'";
$sql = mysqli_query($con, $query);
$data = array();
while ($result = mysqli_fetch_array($sql, MYSQLI_ASSOC)) {
    $quizid = $result['id'];

    $data = array(
        'eventoid' => $result['id'],
        'eventodesc' => $result['nome'],
        'imagem' => $result['imagem'],
        'rating' => ($result['nota'] == null) ? 0 : $result['nota'],
        'comentario' => $result['comentario'],
    );

}

echo json_encode($data);

mysqli_close($con);

?>