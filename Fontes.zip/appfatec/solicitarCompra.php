<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$_POST = json_decode(file_get_contents('php://input'), true);

$empresa = $_POST["empresa"];
$filiado = $_POST["filiado"];
$mensagem = $_POST["mensagem"];
$assunto = $_POST["assunto"];
$produtos = $_POST["produtos"];

if (($empresa === null) || ($empresa === "")) {
    $retorno = array('success' => false, 'message' => 'Empresa não foi definido.');
    echo json_encode($retorno);
    return;
}

if (($filiado === null) || ($filiado === "")) {
    $retorno = array('success' => false, 'message' => 'Filiado não foi definido.');
    echo json_encode($retorno);
    return;
}

include("conexao.php");
include("notificacao.php");

$fornecedor = $empresa['id'];
$comprador = $filiado['empresaid'];
$filiadoid = $filiado['id'];
$mensagem = mysqli_real_escape_string($con, $mensagem);

$sql = "INSERT INTO solicitacao_compra (fornecedor, comprador, filiado, produtos, mensagem, data_hora) VALUES ($fornecedor, $comprador, $filiadoid, '$produtos', '$mensagem', NOW());";
$consulta = mysqli_query($con, $sql);
if ($consulta) {

    $gerentecomercial = $empresa['gerentecomercial'];

    $sql = "SELECT e.* FROM empresa e WHERE e.id = $fornecedor";
    $consulta =  mysqli_query($con, $sql);
    $dadosFornecedor = mysqli_fetch_assoc($consulta);

    $sql = "SELECT e.* FROM empresa e WHERE e.id = $comprador";
    $consulta =  mysqli_query($con, $sql);
    $dadosComprador = mysqli_fetch_assoc($consulta);

    $sql = "SELECT p.* FROM pessoa p WHERE p.id = $filiadoid";
    $consulta =  mysqli_query($con, $sql);
    $dadosFiliado = mysqli_fetch_assoc($consulta);

    $sql = "SELECT p.* FROM pessoa p WHERE p.id = $gerentecomercial";
    $consulta =  mysqli_query($con, $sql);
    $dadosGerente = mysqli_fetch_assoc($consulta);

    $gerentenome = $dadosGerente['nome'];
    $gerenteemail = $dadosGerente['email'];
    $nome = $dadosFiliado['nome'];
    $nomeEmpresa = $dadosComprador['nome'];
    $email = $dadosFiliado['email'];
    $tel = $dadosFiliado['tel'];

    $mensagem = str_replace("\\n", "<br \>", $mensagem);

    $mensagem = " <html>

                <head>
                    <meta charset='utf-8'>
                    <title>TOTVS</title>
                </head>
                
                <body lang='PT-BR' link='#0563C1' vlink='#954F72'>
                    <div class='WordSection1'>
                        <p class='MsoNormal'>
                            <img src=''>
                        </p>
                        <p class='MsoNormal'>
                            <o:p>&nbsp;</o:p>
                        </p>
                        <h2 style='mso-margin-top-alt:15.0pt;margin-right:0cm;margin-bottom:7.5pt;margin-left:0cm'>
                            <span style='font-size:22.5pt;font-family:&quot;Calibri&quot;,sans-serif;color:#333333;font-weight:normal'>
                                Olá, $gerentenome
                            </span>
                        </h2>
                        <p style='mso-margin-top-alt:0cm;margin-right:0cm;margin-bottom:7.5pt;margin-left:0cm;box-sizing: border-box'>
                            <span style='font-size:12.5pt;font-family:&quot;Calibri&quot;,sans-serif;color:#333333'>
                                O filiado <b>$nome</b>, efetuou uma solicitação de compra através do app LIDE Totvs Serra do Mar, segue abaixo a mensagem do filiado juntamente com seus contatos:
                            </span>
                        </p>
                        <p style='mso-margin-top-alt:0cm;margin-right:0cm;margin-bottom:7.5pt;margin-left:0cm;box-sizing: border-box'>
                            <span style='font-size:12.5pt;font-family:&quot;Calibri&quot;,sans-serif;color:#333333'>
                                Nome: <b>$nome</b>
                            </span>
                        </p>
                        <p style='mso-margin-top-alt:0cm;margin-right:0cm;margin-bottom:7.5pt;margin-left:0cm;box-sizing: border-box'>
                            <span style='font-size:12.5pt;font-family:&quot;Calibri&quot;,sans-serif;color:#333333'>
                                Empresa: <b>$nomeEmpresa</b>
                            </span>
                        </p>
                        <p style='mso-margin-top-alt:0cm;margin-right:0cm;margin-bottom:7.5pt;margin-left:0cm;box-sizing: border-box'>
                            <span style='font-size:12.5pt;font-family:&quot;Calibri&quot;,sans-serif;color:#333333'>
                                E-mail: <b>$email</b>
                            </span>
                        </p>
                        <p style='mso-margin-top-alt:0cm;margin-right:0cm;margin-bottom:7.5pt;margin-left:0cm;box-sizing: border-box'>
                            <span style='font-size:12.5pt;font-family:&quot;Calibri&quot;,sans-serif;color:#333333'>
                                Telefone: <b>$tel</b>
                            </span>
                        </p>
                        <p style='mso-margin-top-alt:0cm;margin-right:0cm;margin-bottom:7.5pt;margin-left:0cm;box-sizing: border-box'>
                            <span style='font-size:12.5pt;font-family:&quot;Calibri&quot;,sans-serif;color:#333333'>
                                Mensagem:
                            </span>
                        </p>
                        <p style='mso-margin-top-alt:0cm;margin-right:0cm;margin-bottom:7.5pt;margin-left:0cm;box-sizing: border-box'>
                            <span style='font-size:12.5pt;font-family:&quot;Calibri&quot;,sans-serif;color:#333333'>
                                <b>$mensagem</b>
                            </span>
                        </p>                        
                        <p style='mso-margin-top-alt:0cm;margin-right:0cm;margin-bottom:7.5pt;margin-left:0cm;box-sizing: border-box'>
                            <span style='font-size:8.5pt;font-family:&quot;Calibri&quot;,sans-serif;color:#333333'>
                                    Esta é uma mensagem automática.
                                    <br />Por favor, não responda.
                            </span>
                        </p>
                    </div>
                </body>
                
                </html> ";

    $remetente = array('nome' => "LIDE Totvs Serra do Mar");
    $destinatarios = array();
    array_push($destinatarios, array('email' => $gerenteemail, 'nome' => $gerentenome));
    $assunto = "Compras LIDE Totvs Serra do Mar";
    $ishtml = true;

    $ret = enviarEmail($remetente, $destinatarios, $assunto, $mensagem, $ishtml);

    $retorno = array('success' => true, 'message' => 'Compra solicitada com sucesso.');
} else {
    $retorno = array('success' => false, 'message' => "Erro ao solicitar compra. #1. $sql - Erro:" . mysqli_error($con));
}

mysqli_close($con);

echo json_encode($retorno);
