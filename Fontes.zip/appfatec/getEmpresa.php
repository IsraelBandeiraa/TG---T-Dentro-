<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("conexao.php");
include("imagem.php");

$_POST = json_decode(file_get_contents('php://input'), true);

$iduser = $_POST["iduser"];

$url = full_url( $_SERVER );

if(($iduser === null) || ($iduser === "")){
    $retorno = array('success' => false,'message'=>'Filiado não foi definido.');
    echo json_encode($retorno);
    return;
}

$sql = "SELECT e.* FROM empresa e WHERE e.id = $iduser";
$consulta =  mysqli_query($con,$sql);
$resultado = mysqli_fetch_assoc($consulta);

$imagem = $resultado['foto'];
if(!(substr($imagem, 0, 10) == "data:image")){
    $resultado['foto'] = $url . $imagem;
}


$sql = "SELECT s.* FROM setor s, empresa_setor e WHERE s.id = e.idsetor AND e.idempresa = $iduser";
$consulta =  mysqli_query($con,$sql);
$resultadoSetor = array();
while ($result =  mysqli_fetch_array($consulta, MYSQLI_ASSOC))
{
	array_push($resultadoSetor, $result);
}

$resultado['empresa_setor'] = $resultadoSetor;

$sql = "SELECT p.* FROM produto p, empresa_produto e WHERE p.id = e.idproduto AND e.idempresa = $iduser";
$consulta =  mysqli_query($con,$sql);
$resultadoProduto = array();
while ($result =  mysqli_fetch_array($consulta, MYSQLI_ASSOC))
{
	array_push($resultadoProduto, $result);
}

$resultado['empresa_produto'] = $resultadoProduto;

mysqli_close($con);

$retorno = array('success' => true,'dados'=>$resultado);
echo json_encode($retorno);

?>