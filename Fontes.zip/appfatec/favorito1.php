<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$_POST = json_decode(file_get_contents('php://input'), true);
include "conexao.php";
$idcontato = $_POST["idcontato"];
$solicitante = $_POST["solicitante"];

mysqli_query($con, "SET CHARACTER SET 'utf8'");
$caraio = "select count(id) as contar from contato where  idcontato = $idcontato and solicitante = $solicitante or idcontato = $solicitante and solicitante = $idcontato";

$consulta = mysqli_query($con, $caraio);
$resultado = mysqli_fetch_assoc($consulta);

if ($resultado["contar"] > 0) {
    $caraio1 = "select id from contato where  idcontato = $idcontato and solicitante = $solicitante or idcontato = $solicitante and solicitante = $idcontato";

    $consulta1 = mysqli_query($con, $caraio1);
    $resultado1 = mysqli_fetch_assoc($consulta1);
    
    $sql = "update contato set favorito = 0 where id = " . $resultado1["id"] . "";
    mysqli_query($con, $sql);
    $resposta = '{"success" : true}';
} else {
    $resposta = '{"success" : false}';
}
echo $resposta;

mysqli_close($con);

?>