<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$_POST = json_decode(file_get_contents('php://input'), true);
include("conexao.php");
   
    $iduser = $_POST["id"];
    $idpost = $_POST["idpost"];
      
    $compara =  "select count(id) as contar  from postcurtida where idpost = '".$idpost."' and iduser ='".$iduser."'";
    $consulta =  mysqli_query($con,$compara);
    $resultado = mysqli_fetch_assoc($consulta);
    
     if($resultado["contar"] == 0) {

        $sql = "insert into postcurtida(idpost, iduser, curtiu) values ($idpost, $iduser, 1)";
        mysqli_query($con, $sql);

        $resposta = '{"success" : true, "mensagem" : "Publicação Curtida com Sucesso!!"}';


     }
     else{

        $sql = "delete from postcurtida where idpost = '".$idpost."' and iduser ='".$iduser."'";
        mysqli_query($con, $sql);
        $resposta = '{"success" : false, "mensagem" : "Você descurtiu esse post"}';
     }
 
     echo $resposta;

     mysqli_close($con);

?>