<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("conexao.php");
include("imagem.php");

mysqli_query($con, "SET NAMES 'utf8'");
mysqli_query($con, "SET CHARACTER SET 'utf8'");

$_POST = json_decode(file_get_contents('php://input'), true);

$empresa = $_POST["idempresa"];

$url = full_url($_SERVER);

if (($empresa === null) || ($empresa === "")) {
  $retorno = array('success' => false, 'message' => 'Empresa não foi definida.');
  echo json_encode($retorno);
  return;
}

$sql = "SELECT e.* FROM empresa e WHERE e.id = $empresa";
$consulta =  mysqli_query($con, $sql);
$resultado = mysqli_fetch_assoc($consulta);

$imagem = $resultado['foto'];
if ((!(substr($imagem, 0, 10) == "data:image")) && ($imagem != "")) {
  $resultado['foto'] = $url . $imagem;
}

$sql = "SELECT p.* FROM produto p, empresa_produto e WHERE p.id = e.idproduto AND e.idempresa = $empresa";
$consultaProduto =  mysqli_query($con, $sql);
$resultadoProduto = array();
while ($result =  mysqli_fetch_array($consultaProduto, MYSQLI_ASSOC)) {
  array_push($resultadoProduto, $result);
}
$resultado['produtos'] = $resultadoProduto;

$sql = "SELECT s.* FROM setor s, empresa_setor e WHERE s.id = e.idsetor AND e.idempresa = $empresa";
$consultaSetor =  mysqli_query($con, $sql);
$resultadoSetor = array();
while ($result =  mysqli_fetch_array($consultaSetor, MYSQLI_ASSOC)) {
  array_push($resultadoSetor, $result);
}
$resultado['setores'] = $resultadoSetor;

$sql = "SELECT p.* FROM pessoa p WHERE p.empresaid = $empresa AND perfil = 'FILIADO' AND teste <> 1 AND status = 1";
$consultaFiliado =  mysqli_query($con, $sql);
$resultadoFiliado = array();
while ($result =  mysqli_fetch_array($consultaFiliado, MYSQLI_ASSOC)) {
  $imagem = $result['imagem'];
  if ((!(substr($imagem, 0, 10) == "data:image")) && ($imagem != "")) {
    $result['imagem'] = $url . $imagem;
  }
  array_push($resultadoFiliado, $result);
}
$resultado['filiados'] = $resultadoFiliado;


mysqli_close($con);



echo json_encode($resultado);
