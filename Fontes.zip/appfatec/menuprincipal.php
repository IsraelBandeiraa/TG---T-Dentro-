<?php
header("Access-Control-Allow-Origin: *");
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("conexao.php");
$_POST = json_decode(file_get_contents('php://input'), true);
$id = $_POST["id"];
$versao = $_POST["versao"];

function getBadge($result, $notificacoes)
{

    $qtd = "0";
    if ($result['codMenu'] == 2) {
        $qtd = $notificacoes['evento'];
    } else if ($result['codMenu'] == 4) {
        $qtd = $notificacoes['contato'];
    } else if ($result['codMenu'] == 6) {
        $qtd = $notificacoes['post'];
    } else if ($result['codMenu'] == 7) {
        $qtd = $notificacoes['chat'];
    } else if ($result['codMenu'] == 9) {
        $qtd = $notificacoes['beneficio'];
    } else if ($result['codMenu'] == 10) {
        $qtd = $notificacoes["quiz"];
    }
    $qtd = intval($qtd);

    return $qtd;
}

#Consulta de Eventos Ativos#
$sql = "SELECT 
    perfil,
    admin,
    (SELECT COUNT(id) AS total FROM notificacaousuario WHERE lido = 0 AND userid = p.id) total,
    (SELECT COUNT(DISTINCT objetoid) AS evento FROM notificacaousuario WHERE tipo IN ('NOVOEVENTO','ALTERACAOEVENTO')  AND lido = 0 AND userid = p.id) evento,
    (SELECT COUNT(DISTINCT objetoid) AS chat FROM notificacaousuario WHERE tipo IN ('NOVOCHAT') AND lido = 0 AND userid = p.id) chat,
    (SELECT COUNT(DISTINCT objetoid) AS contato FROM notificacaousuario WHERE tipo IN ('NOVOCONTATO') AND lido = 0 AND userid = p.id) contato,
    (SELECT COUNT(DISTINCT objetoid) AS post FROM notificacaousuario WHERE tipo IN ('NOVOFEED') AND lido = 0 AND userid = p.id) post,
    (SELECT COUNT(DISTINCT objetoid) AS beneficio FROM notificacaousuario WHERE tipo IN ('NOVOBENEFICIO') AND lido = 0 AND userid = p.id) beneficio,
    (SELECT COUNT(DISTINCT objetoid) AS quiz FROM notificacaousuario WHERE tipo IN ('NOVOQUIZ') AND lido = 0 AND userid = p.id) quiz
    FROM pessoa p
    WHERE id = '$id'";
$consulta =  mysqli_query($con, $sql);
$notificacoes = mysqli_fetch_assoc($consulta);
#Consulta de Eventos Ativos#

if (!$versao) {

    $menusB = array();
    array_push($menusB, array('menuE' => 0, 'labelE' => "Próximos eventos", 'qtdNotE' => $notificacoes['evento'], 'iconeE' => "md-calendar", 'imgE' => "", 'validarFiliadoE' => "1", 'menuD' => 1, 'labelD' => "Confirmar presença em eventos", 'qtdNotD' => 0, 'iconeD' => "md-flag", 'imgD' => "", 'validarFiliadoD' => "1"));
    array_push($menusB, array('menuE' => 2, 'labelE' => "Check in / Out de Evento", 'qtdNotE' => 0, 'iconeE' => "md-checkmark", 'imgE' => "", 'validarFiliadoE' => "1", 'menuD' => 3, 'labelD' => "Minha rede", 'qtdNotD' => $notificacoes['contato'], 'iconeD' => "md-people", 'imgD' => "", 'validarFiliadoD' => "1"));
    array_push($menusB, array('menuE' => 4, 'labelE' => "Filiados LIDE Noroeste Paulista ou Filiados LIDE Futuro Noroeste Paulista", 'qtdNotE' => 0, 'iconeE' => "md-briefcase", 'imgE' => "", 'validarFiliadoE' => "1", 'menuD' => 5, 'labelD' => "Compartilhe seu sucesso", 'qtdNotD' => $notificacoes['post'], 'iconeD' => "md-share", 'imgD' => "", 'validarFiliadoD' => "1"));
    array_push($menusB, array('menuE' => 6, 'labelE' => "Chat", 'qtdNotE' => $notificacoes['chat'], 'iconeE' => "ios-chatbubbles", 'imgE' => "", 'validarFiliadoE' => "1", 'menuD' => 7, 'labelD' => "Perguntas/Feedback", 'qtdNotD' => 0, 'iconeD' => "md-help", 'imgD' => "", 'validarFiliadoD' => "1"));
    array_push($menusB, array('menuE' => 8, 'labelE' => "Benefícios", 'qtdNotE' => $notificacoes['beneficio'], 'iconeE' => "md-pricetags", 'imgE' => "", 'validarFiliadoE' => "1", 'menuD' => 9, 'labelD' => "Quiz", 'qtdNotD' => $notificacoes["quiz"], 'iconeD' => "md-text", 'imgD' => "", 'validarFiliadoD' => "1"));

    $menusA = array();

    echo json_encode(array("menus" => $menusB, "rowmenus" => $menusA, "totalNotificaoces" => intval($notificacoes['total'])));

    return;
}

$perfis = "''";
if ($notificacoes['admin'] == "1") {
    $perfis = "'ADMIN','FILIADO','HEAD'";
} else if ($notificacoes['perfil'] == "FILIADO") {
    $perfis = "'FILIADO','HEAD'";
} else if ($notificacoes['perfil'] == "HEAD") {
    $perfis = "'HEAD'";
}

$query = "SELECT * FROM menus WHERE posicao IN ('B') AND perfil IN ($perfis) AND versao <= $versao ORDER BY ordem";
$sql = mysqli_query($con, $query);
$menusB = array();
while ($result =  mysqli_fetch_array($sql, MYSQLI_ASSOC)) {
    $qtd = getBadge($result, $notificacoes);
    array_push($menusB, array("img" => $result['imagem'], "badge" => $qtd, "label" => $result['descricao'], "menu" => intval($result['codMenu']), "icone" => $result['icone'], 'pefil' => $result['perfil']));
}

$query = "SELECT * FROM menus WHERE posicao IN ('A') AND perfil IN ($perfis) AND versao <= $versao ORDER BY ordem";
$sql = mysqli_query($con, $query);
$menusA = array();
while ($result =  mysqli_fetch_array($sql, MYSQLI_ASSOC)) {
    $qtd = getBadge($result, $notificacoes);
    array_push($menusA, array("img" => $result['imagem'], "badge" => $qtd, "label" => $result['descricao'], "menu" => intval($result['codMenu']), "icone" => $result['icone'], 'pefil' => $result['pefil']));
}

$query = "SELECT * FROM menus WHERE perfil IN ($perfis) AND versao <= $versao ORDER BY ordemlateral";
$sql = mysqli_query($con, $query);
$menusL = array();
while ($result =  mysqli_fetch_array($sql, MYSQLI_ASSOC)) {
    $qtd = getBadge($result, $notificacoes);
    array_push($menusL, array("img" => $result['imagem'], "badge" => $qtd, "label" => $result['descricao'], "menu" => intval($result['codMenu']), "icone" => $result['icone'], 'pefil' => $result['pefil']));
}

echo json_encode(array("menuslateral" => $menusL, "menus" => $menusB, "rowmenus" => $menusA, "totalNotificaoces" => intval($notificacoes['total'])));
