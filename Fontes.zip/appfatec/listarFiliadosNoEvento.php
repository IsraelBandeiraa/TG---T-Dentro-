<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("conexao.php");

$_POST = json_decode(file_get_contents('php://input'), true);

$idEvento = $_POST["idEvento"];

if(($idEvento === null) || ($idEvento === "")){
    $retorno = array('success' => false,'message'=>'Evento não foi definido.');
    echo json_encode($retorno);
    return;
}

$query = "SELECT pe.id,p.id idpessoa,p.nome,p.email,p.status,p.lide,p.lidefuturo,p.patrocinador,p.empresa FROM pessoa p,primeiroevento pe WHERE p.id = pe.idpessoa AND pe.idevento = $idEvento ORDER BY nome";

$sql= mysqli_query($con, $query);
$data = array();
while ($result =  mysqli_fetch_array($sql, MYSQLI_ASSOC))
{

	array_push($data, array('id' => $result['id'],
		'idpessoa' => $result['idpessoa'], 
		'nome' => $result['nome'], 
		'email' => $result['email'],
		'status' => $result['status'],
		'lide' => $result['lide'],
		'lidefuturo' => $result['lidefuturo'],
		'empresa' => $result['empresa'],
		'patrocinador' => $result['patrocinador']));

}

mysqli_close($con);

$retorno = array('success' => true,'dados'=>$data);

echo json_encode($retorno);

?>