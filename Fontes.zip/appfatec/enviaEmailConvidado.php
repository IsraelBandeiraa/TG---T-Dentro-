<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$_POST = json_decode(file_get_contents('php://input'), true);
$conteudoQR = $_POST["idUser"];
$nomeEvento = $_POST["nomeEvento"];
$dataEvento = $_POST["dataEvento"];
$horaEvento = $_POST["horaEvento"];
$nome = $_POST["nome"];
$imgQrCode = "QR_code" . $conteudoQR . ".png";

include("conexao.php");
include("notificacao.php");
include("geraQrCode.php");

$mensagem = " 

<html>
        <body lang='PT-BR' link='#0563C1' vlink='#954F72'>
            <div class='WordSection1'>
                <p class='MsoNormal'>
                    <img src=''</p>
                <p class='MsoNormal'>
                    <o:p>&nbsp;</o:p>
                </p>
                <h2 style='mso-margin-top-alt:15.0pt;margin-right:0cm;margin-bottom:7.5pt;margin-left:0cm'>
                    <span style='font-size:22.5pt;font-family:&quot;Calibri&quot;,sans-serif;color:#333333;font-weight:normal'>
                        Olá, $nome
                    </span>
                </h2>
                <p style='mso-margin-top-alt:0cm;margin-right:0cm;margin-bottom:7.5pt;margin-left:0cm;box-sizing: border-box'>
                    <span style='font-size:12.5pt;font-family:&quot;Calibri&quot;,sans-serif;color:#333333'>
                    Seu cadastro foi efetuado com sucesso para participação do evento $nomeEvento, no dia $dataEvento às $horaEvento, para ter acesso ao evento apresente a credencial abaixo para a equipe organizadora. 
                    </span>
                </p>
                <br><br><br

            </div>

            <body style='margin:0;padding:0;box-sizing:border-box;font-family:Arial,sans-serif'>

            <div style='max-width:400px;width:100%;margin:auto;padding-top:30px;border:1px solid#ccc; border-radius: 30px; text-align: center; position: relative'>

            <img src='https://i.ibb.co/mXQTnYz/logoemail.png' alt='Logo' style='max-width: 100%; height: auto; margin-bottom: 20px'/>

            <div style='background-color: black; height: 300px; width: 100%'>

            <br>
            <p style='color: white; font-size: 25px; margin:20px'>$nome</p>
            <p style='color: white; font-size: 18px'>CONVIDADO</p>
            
            <img src='https://www.clientestotvssm.com.br/appfatec/qrcodes/$imgQrCode' alt='Pequena Imagem' style='max-width: 70px; height: auto'>
            </div>
            
            <p style='font-size: 16px; margin-bottom: 100px;'></p>

     


    
            <html>
            
            <head>
                <meta charset="UTF-8">
                <title>Cartão de Entrada - Evento</title>
                <style>
                    body {
                        font-family: "Arial", sans-serif;
                        background-color: #EDEDED;
                    }
            
                    .card {
                        max-width: 300px;
                        width: 100%;
                        margin: 20px auto;
                        padding: 20px;
                        border: 1px solid #333;
                        border-radius: 10px;
                        background-color: #FFFFFF;
                        text-align: center;
                    }
            
                    .logo {
                        max-width: 120px;
                        height: auto;
                        margin-bottom: 20px;
                    }
            
                    .event-title {
                        font-size: 24px;
                        font-weight: bold;
                        margin-bottom: 10px;
                    }
            
                    .name {
                        font-size: 20px;
                    }
            
                    .date-time {
                        font-size: 18px;
                    }
            
                    .venue {
                        font-size: 16px;
                        margin-top: 10px;
                    }
            
                    .entry-code {
                        font-size: 16px;
                        margin-top: 20px;
                    }
                </style>
            </head>
            
            <body>
            
            < class="card">
                <img src="https://i.ibb.co/mXQTnYz/logoemail.png" alt="Logo" class="logo">
                <p class="event-title">$nomeEvento</p>
                <p class="name">$nome</p>
                <p class="date-time">Data e Hora: $dataEvento às $horaEvento</p>
                <p class="venue">Local: $localEvento</p>
                <p class="entry-code">Código de Entrada: $imgQrCode</p>
            </div>
            
            </body>
            
            </html>
            
       
</html>";

$remetente = array('nome' => "Tô Dentro!");
$destinatarios = array();
array_push($destinatarios, array('email' => $_POST['email'], 'nome' => $_POST['nome']));
$assunto = "Credencial do Evento";

$ishtml = true;

enviarEmail($remetente, $destinatarios, $assunto, $mensagem, $ishtml);

$retorno = array('success' => true, 'message' => $resposta);
echo json_encode($retorno);

mysqli_close($con);
