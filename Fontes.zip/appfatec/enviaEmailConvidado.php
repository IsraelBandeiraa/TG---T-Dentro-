<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$_POST = json_decode(file_get_contents('php://input'), true);
$conteudoQR = $_POST["idUser"];
$nomeEvento = $_POST["nomeEvento"];
$dataEvento = $_POST["dataEvento"];
$horaEvento = $_POST["horaEvento"];
$imgQrCode = "QR_code" . $conteudoQR . ".png";

include("conexao.php");
include("notificacao.php");
include("geraQrCode.php");

$mensagem = " <html>
    
        <head>
            <meta charset='utf-8'>
            <title>TOTVS</title>
        </head>
        
        <body lang='PT-BR' link='#0563C1' vlink='#954F72'>
            <div class='WordSection1'>
                <p class='MsoNormal'>
                    <img src=''>
                </p>
                <p class='MsoNormal'>
                    <o:p>&nbsp;</o:p>
                </p>
                <h2 style='mso-margin-top-alt:15.0pt;margin-right:0cm;margin-bottom:7.5pt;margin-left:0cm'>
                    <span style='font-size:22.5pt;font-family:&quot;Calibri&quot;,sans-serif;color:#333333;font-weight:normal'>
                        Olá, 
                    </span>
                </h2>
                <p style='mso-margin-top-alt:0cm;margin-right:0cm;margin-bottom:7.5pt;margin-left:0cm;box-sizing: border-box'>
                    <span style='font-size:12.5pt;font-family:&quot;Calibri&quot;,sans-serif;color:#333333'>
                    Seu cadastro foi efetuado com sucesso para participação do evento $nomeEvento, favor apresentar o QR Code abaixo para fazer check-in. 
                    </span>
                </p>
                <p style='mso-margin-top-alt:0cm;margin-right:0cm;margin-bottom:7.5pt;margin-left:0cm;box-sizing: border-box'>
                    <span style='font-size:12.5pt;font-family:&quot;Calibri&quot;,sans-serif;color:#333333'>
                        <br />
                        <img src='https://www.clientestotvssm.com.br/appfatec/qrcodes/$imgQrCode'/>
                    </span>
                </p>
                <p style='mso-margin-top-alt:0cm;margin-right:0cm;margin-bottom:7.5pt;margin-left:0cm;box-sizing: border-box'>
                    <span style='font-size:12.5pt;font-family:&quot;Calibri&quot;,sans-serif;color:#333333'>
                        Data: $dataEvento
                    </span>
                </p>
                <p style='mso-margin-top-alt:0cm;margin-right:0cm;margin-bottom:7.5pt;margin-left:0cm;box-sizing: border-box'>
                    <span style='font-size:12.5pt;font-family:&quot;Calibri&quot;,sans-serif;color:#333333'>
                        Hora: $horaEvento
                    </span>
                </p>
                <p style='mso-margin-top-alt:0cm;margin-right:0cm;margin-bottom:7.5pt;margin-left:0cm;box-sizing: border-box'>
                    <span style='font-size:8.5pt;font-family:&quot;Calibri&quot;,sans-serif;color:#333333'>
                            Esta é uma mensagem automática.
                            <br />Por favor, não responda.
                      </span>
                </p>
            </div>
        </body>
        
        </html> ";

$remetente = array('nome' => "LIDE TOTVS SERRA DO MAR");
$destinatarios = array();
array_push($destinatarios, array('email' => $_POST['email'], 'nome' => $_POST['nome']));
/*array_push($destinatarios, array('email' => 'marta@mhsconsultoria.com.br', 'nome' => '', 'tipo' => 'cco'));
array_push($destinatarios, array('email' => 'alessandra@mhsconsultoria.com.br', 'nome' => '', 'tipo' => 'cco'));
array_push($destinatarios, array('email' => 'suporte@lidenoroestepaulista.com.br', 'nome' => '', 'tipo' => 'cco'));
array_push($destinatarios, array('email' => 'aldo.guerra@totvs.com.br', 'nome' => '', 'tipo' => 'cco'));*/
$assunto = "Confirmação de Evento - QR CODE";
$ishtml = true;

enviarEmail($remetente, $destinatarios, $assunto, $mensagem, $ishtml);

$retorno = array('success' => true, 'message' => $resposta);
echo json_encode($retorno);

mysqli_close($con);
