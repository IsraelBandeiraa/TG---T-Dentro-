<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$_POST = json_decode(file_get_contents('php://input'), true);
include("conexao.php");
   
    $titulo = $_POST["titulo"];
    $idevento = $_POST["idevento"];
    $ativo = $_POST["ativo"];
    $url = $_POST["url"];
      

    $compara = "select count(id) as contar from quiz where idevento = '$idevento' ";
    $contar = mysqli_query($con, $compara);
    $sim = mysqli_fetch_assoc($contar);

    if($sim["contar"] == 0){
    
    $sql = "insert into quiz (idevento, titulo, ativo, url, notificado) values ('$idevento','$titulo','$ativo', '$url', 0)";   
     
    mysqli_query($con, $sql);
    }

     mysqli_close($con);

?>