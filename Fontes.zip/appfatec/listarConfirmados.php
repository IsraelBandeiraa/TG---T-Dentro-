<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("conexao.php");

$_POST = json_decode(file_get_contents('php://input'), true);

$idEvento = $_POST["idEvento"];

if(($idEvento === null) || ($idEvento === "")){
    $retorno = array('success' => false,'message'=>'Evento não foi definido.');
    echo json_encode($retorno);
    return;
}

$query = "SELECT p.id,p.nome,p.email,p.status,p.lide,p.lidefuturo,p.patrocinador,p.empresa,p.teste,c.pagante FROM pessoa p,evento e,checkin c WHERE c.idevento = e.id AND c.iduser = p.id AND e.id = $idEvento AND (c.confirmar = 1 OR c.confirmoumanual = 1) ORDER BY nome";

$sql= mysqli_query($con, $query);
$data = array();
while ($result =  mysqli_fetch_array($sql, MYSQLI_ASSOC))
{

	array_push($data, array('id' => $result['id'], 
		'nome' => $result['nome'], 
		'email' => $result['email'],
		'status' => $result['status'],
		'teste' => $result['teste'],
		'lide' => $result['lide'],
		'lidefuturo' => $result['lidefuturo'],
		'empresa' => $result['empresa'],
        'patrocinador' => $result['patrocinador'],
        'pagante' => $result['pagante']
    ));

}

mysqli_close($con);

echo json_encode($data);

?>