<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$_POST = json_decode(file_get_contents('php://input'), true);

if(($_GET["id"] === null) || ($_GET["id"] === "")){
    $retorno = array('success' => false,'message'=>'Impressão não foi definido.');
    echo json_encode($retorno);
    return;
}

$id = $_GET["id"];

include("conexao.php");

$sql = "DELETE FROM imprimir WHERE id = $id";
$consulta =  mysqli_query($con,$sql);
if($consulta){
    $retorno = array('success' => true,'message'=>'Impressão deletada com sucesso.');
}else{
    $retorno = array('success' => false,'message'=>'Erro ao deletar impressão.');
}
echo json_encode($retorno);


?>