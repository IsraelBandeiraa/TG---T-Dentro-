<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("conexao.php");

$_POST = json_decode(file_get_contents('php://input'), true);
$id = $_POST["id"];
mysqli_query($con, "SET NAMES 'utf8'");
mysqli_query($con, "SET CHARACTER SET 'utf8'");
//$query = "SELECT * FROM evento WHERE status = 1 AND data >= CURRENT_DATE ORDER BY data ASC";
$query_usuario = "SELECT * FROM pessoa WHERE id = $id;";
$sql_usuario = mysqli_query($con, $query_usuario);
while($result_usuario = mysqli_fetch_array($sql_usuario, MYSQLI_ASSOC)) {
  $q = "
    select
      ev.id as id,
      ev.nome as nome,
      ev.imagem as imagem,
      ev.endereco as endereco,
      ev.status as status,
      ev.data as data,
      ev.latitude as latitude,
      ev.longitude as longitude,
      ev.lide as lide,
      ev.lidefuturo as lidefuturo,
      ev.descricao as descricao
    from evento as ev, (select lide, lidefuturo from pessoa where id = '".$result_usuario['id']."') as li
    where
      ev.status = 1
      and ev.data >= CURRENT_DATE ";

    if ($result_usuario['lide'] == 1 && $result_usuario['lidefuturo'] == 1) {
      $q = $q."and (ev.lide = 1 or ev.lidefuturo = 1)";
    } else if ($result_usuario['lide'] == 1) {
      $q = $q."and ev.lide = 1";
    } else if ($result_usuario['lidefuturo'] == 1) {
      $q = $q."and ev.lidefuturo = 1";
    }
    $q = $q." order by ev.data asc;";
}

$sql= mysqli_query($con, $q);
$data = array();

while ($result =  mysqli_fetch_array($sql, MYSQLI_ASSOC)){
  array_push($data, array(
    'id' => $result['id'],
    'nome' => $result['nome'],
    'imagem' => $result['imagem'],
    'endereco' => $result['endereco'],
    'status' => $result['status'],
    'data' => $result['data'],
    'lat' => $result['latitude'],
    'long' => $result['longitude'],
    'lide' => $result['lide'],
    'lidefuturo' => $result['lidefuturo'],
    'descricao' => ''
  ));
}
echo json_encode($data);

mysqli_close($con);
?>

