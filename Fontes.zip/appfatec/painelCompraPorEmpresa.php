<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("conexao.php");
include("imagem.php");

$_POST = json_decode(file_get_contents('php://input'), true);

$filiadoid = $_POST["filiadoid"];
$empresaid = $_POST["empresaid"];

$url = full_url($_SERVER);

$sql = "SELECT e.*, 
                p.nome gerentenome,
                (SELECT COUNT(*) FROM solicitacao_compra WHERE fornecedor = e.id AND comprador = '$empresaid') numSolic
        FROM empresa e, pessoa p 
        WHERE (SELECT COUNT(*) FROM empresa_produto ep WHERE ep.idempresa = e.id) > 0 
        AND e.gerentecomercial = p.id";
$consulta =  mysqli_query($con, $sql);
$resultadoEmpresa = array();
while ($resultado =  mysqli_fetch_array($consulta, MYSQLI_ASSOC)) {
    $empresa = $resultado['id'];

    $imagem = $resultado['foto'];
    if ((!(substr($imagem, 0, 10) == "data:image")) && ($imagem != "")) {
        $resultado['foto'] = $url . $imagem;
    }

    $sql = "SELECT p.* FROM produto p, empresa_produto e WHERE p.id = e.idproduto AND e.idempresa = $empresa";
    $consultaProduto =  mysqli_query($con, $sql);
    $resultadoProduto = array();
    while ($result =  mysqli_fetch_array($consultaProduto, MYSQLI_ASSOC)) {
        array_push($resultadoProduto, $result);
    }
    $resultado['produtos'] = $resultadoProduto;

    $sql = "SELECT s.* FROM setor s, empresa_setor e WHERE s.id = e.idsetor AND e.idempresa = $empresa";
    $consultaSetor =  mysqli_query($con, $sql);
    $resultadoSetor = array();
    while ($result =  mysqli_fetch_array($consultaSetor, MYSQLI_ASSOC)) {
        array_push($resultadoSetor, $result);
    }
    $resultado['setores'] = $resultadoSetor;

    array_push($resultadoEmpresa, $resultado);
}

mysqli_close($con);



$retorno = array(
    'success' => true,
    'dados' => $resultadoEmpresa,
    'assunto' => 'Orçamento de Produtos através do LIDE',
    'mensagem' => 'Sou o filiado do LIDE Totvs Serra do Mar {{filiado}} e desejo solicitar o orçamento dos seguintes produtos:\n{{produtos}}'
);
echo json_encode($retorno);
