<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$_POST = json_decode(file_get_contents('php://input'), true);
include "conexao.php";
include "notificacao.php";

$idcontato = $_POST["idcontato"];
$solicitante = $_POST["solicitante"];
$userid = $_POST["userid"];

$sql = "insert into contato (idcontato, solicitante, userid, aceito, notificado, novo) values ('$idcontato','$solicitante', '$userid', 0 , 0, 0)";

echo $sql."\n";

$ret = enviarNotificacao($con,"NOVOCONTATO",$solicitante,"",array('receiverid' => $idcontato));

echo json_encode($ret)."\n";

mysqli_query($con, $sql);

mysqli_close($con);

?>