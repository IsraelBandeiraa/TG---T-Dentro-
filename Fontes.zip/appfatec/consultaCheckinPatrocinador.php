<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("conexao.php");
try {
    $_POST = json_decode(file_get_contents('php://input'), true);
    mysqli_query($con, "SET NAMES 'utf8'");
    mysqli_query($con, "SET CHARACTER SET 'utf8'");
    $idevento = $_POST["idevento"];
    $idPatrocinador = $_POST["idPatrocinador"];
    $query = "SELECT p.nome, p.email, p.empresa, c.*  from checkin AS c
    LEFT JOIN pessoa AS p ON p.id = c.iduser
    where idevento = $idevento AND id_patrocinador = $idPatrocinador";
    $sql = mysqli_query($con, $query);
    $arr = array();
    while ($result = mysqli_fetch_array($sql, MYSQLI_ASSOC)) {
        array_push($arr, array(
            'id' => $result['id'],
            'idevento' => $result['idevento'],
            'iduser' => $result['iduser'],
            'latitude' => $result['latitude'],
            'longitude' => $result['longitude'],
            'confirmar' => $result['confirmar'],
            'checkin' => $result['checkin'],
            'checkout' => $result['checkout'],
            'notificado' => $result['notificado'],
            'impresso' => $result['impresso'],
            'checkindatahora' => $result['checkindatahora'],
            'checkoutdatahora' => $result['checkoutdatahora'],
            'confirmardatahora' => $result['confirmardatahora'],
            'confirmoumanual' => $result['confirmoumanual'],
            'checkinmanual' => $result['checkinmanual'],
            'checkoutmanual' => $result['checkoutmanual'],
            'pagante' => $result['pagante'],
            'id_patrocinador' => $result['id_patrocinador'],
            'obsConvidado' => $result['obsConvidado'],
            'nome' => $result['nome'],
            'email' => $result['email'],
            'empresa' => $result['empresa']
        ));
    }
    $retorno = array('success' => false, 'dados' => $arr, 'message' => 'Consulta realizada com sucesso.');
    echo json_encode($retorno);
    mysqli_close($con);
} catch (Exception $e) {
    mysqli_close($con);
    $retorno = array('success' => false, 'dados' => null, 'message' => 'Exceção capturada: ' .  $e->getMessage());
    echo json_encode($retorno);
}
