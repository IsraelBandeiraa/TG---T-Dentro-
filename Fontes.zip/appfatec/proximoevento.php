<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("conexao.php");
   
mysqli_query($con, "SET NAMES 'utf8'"); 
mysqli_query($con, "SET CHARACTER SET 'utf8'"); 
$sql = "SELECT * FROM evento WHERE status = 1 and data >= CURRENT_DATE ORDER BY data ASC limit 1";
$consulta =  mysqli_query($con,$sql);
$resultado = mysqli_fetch_assoc($consulta);
echo json_encode($resultado);
mysqli_close($con);
?>