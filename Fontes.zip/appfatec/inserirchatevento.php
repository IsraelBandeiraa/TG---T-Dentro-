<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$_POST = json_decode(file_get_contents('php://input'), true);
include("conexao.php");
   
    $senderid = $_POST["senderid"];
    $idevento = $_POST["idevento"];
    $mensagem = $_POST["mensagem"];
      
    $sql = "insert into chatevento (idevento, senderid, mensagem, data, lido) values ('$idevento','$senderid','$mensagem', CURRENT_DATE, 0)";
    
    echo $sql;
 
    mysqli_query($con, $sql);

     mysqli_close($con);

?>