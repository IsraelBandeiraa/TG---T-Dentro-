<?php
header("Access-Control-Allow-Origin: *");
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

include("notificacao.php");

$_POST = json_decode(file_get_contents('php://input'), true);

$remetente = $_POST["remetente"];
$destinatarios = $_POST["destinatarios"];
$assunto = $_POST["assunto"];
$mensagem = $_POST["mensagem"];
$ishtml = $_POST["ishtml"];

echo enviarEmail($remetente, $destinatarios, $assunto, $mensagem, $ishtml);
