<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("conexao.php");

$_POST = json_decode(file_get_contents('php://input'), true);

$query = "SELECT p.id,p.nome,p.email,p.status,p.lide,p.lidefuturo,p.patrocinador,p.empresa,p.imagem FROM pessoa p WHERE modificado = 1 AND imagem LIKE 'data:image%' ";

$sql= mysqli_query($con, $query);
$data = array();
while ($result =  mysqli_fetch_array($sql, MYSQLI_ASSOC))
{

	array_push($data, array('id' => $result['id'], 
		'nome' => $result['nome'], 
		'email' => $result['email'],
		'lide' => $result['lide'],
		'lidefuturo' => $result['lidefuturo'],
		'empresa' => $result['empresa'],
		'patrocinador' => $result['patrocinador'],
		'imagem' => $result['imagem']));

}

mysqli_close($con);

echo json_encode($data);


?>