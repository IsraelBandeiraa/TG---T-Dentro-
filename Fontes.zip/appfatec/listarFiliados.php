<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("conexao.php");

$_POST = json_decode(file_get_contents('php://input'), true);

$idEvento = $_POST["idEvento"];

if ($idEvento == ""){
	$query = "SELECT p.id,p.nome,p.email,p.status,p.lide,p.lidefuturo,p.lidemulher,p.patrocinador,p.empresa,p.teste,p.perfil FROM pessoa p ORDER BY nome";
}else{
	$query = "SELECT p.id,p.nome,p.email,p.status,p.lide,p.lidefuturo,p.lidemulher,p.patrocinador,p.empresa,p.teste,p.perfil FROM pessoa p,evento e WHERE e.id = $idEvento AND (p.lide = e.lide OR p.lidefuturo = e.lidefuturo) ORDER BY nome";
}

$sql= mysqli_query($con, $query);
$data = array();
while ($result =  mysqli_fetch_array($sql, MYSQLI_ASSOC))
{

	array_push($data, array('id' => $result['id'], 
		'nome' => $result['nome'], 
		'email' => $result['email'],
		'status' => $result['status'],
		'teste' => $result['teste'],
		'lide' => $result['lide'],
		'lidefuturo' => $result['lidefuturo'],
		'lidemulher' => $result['lidemulher'],
		'perfil' => $result['perfil'],
		'empresa' => $result['empresa'],
		'patrocinador' => $result['patrocinador']));

}

mysqli_close($con);

echo json_encode($data);

?>