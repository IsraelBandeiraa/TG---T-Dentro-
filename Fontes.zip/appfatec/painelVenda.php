<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("conexao.php");
include("imagem.php");

$_POST = json_decode(file_get_contents('php://input'), true);

$filiadoid = $_POST["filiadoid"];
$empresaid = $_POST["empresaid"];

$url = full_url($_SERVER);

$sql = "SELECT sv.*, p.nome solicitante
        FROM solicitacao_venda sv,
            pessoa p
        WHERE sv.filiado = p.id
        AND filiado_empresa = '$empresaid' ";

$consulta =  mysqli_query($con, $sql);
$realizadas = array();
while ($resultado =  mysqli_fetch_array($consulta, MYSQLI_ASSOC)) {
    array_push($realizadas, $resultado);
}

$liberadas = array();
$permitidasInternas = 0;
$permitidasExternas = 0;





mysqli_close($con);



$retorno = array(
    'success' => true,
    'realizadas' => $realizadas,
    'liberadas' => $liberadas,
    'info' => '',
    'assunto' => 'Concierge através do LIDE',
    'mensagem' => 'Sou o filiado do LIDE Noroeste Paulista {{filiado}} e desejo solicitar o contato com a empresa acima citada para realizar a venda de meus produtos.'
);
echo json_encode($retorno);
