<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

include("imagem.php");
include("conexao.php");

$_POST = json_decode(file_get_contents('php://input'), true);
mysqli_query($con, "SET NAMES 'utf8'"); 
mysqli_query($con, "SET CHARACTER SET 'utf8'");

// $inicio = $_POST["inicio"];
// $fim = $_POST["fim"];

$query = "SELECT * FROM promocao where ativo = 1 order by id desc"; //limit $inicio, $fim
$sql= mysqli_query($con, $query);
$data = array();
while ($result =  mysqli_fetch_array($sql, MYSQLI_ASSOC))
{

    $foto = $result['foto'];
    if (($foto != '') && (!(substr($foto, 0, 10) == "data:image"))) {
        $result['foto'] = $url . $foto;
    }

    array_push($data, array(
        'id' => $result['id'], 
        'foto' => $result['foto'], 
        'data' => $result['data'],
        'titulo' => $result['titulo'],
        'texto' => $result['texto'],
        'empresa' => $result['empresa'],
        'link' => $result['link'],
      
    ));
}

echo json_encode($data);
mysqli_close($con);

?>