<?php

function salvarImagemDisco($strImagem,$idcampo,$tabela){

    $extensao = explode("/", $strImagem)[1];
    $extensao = explode(";", $extensao)[0];
    $base64 = explode(",", $strImagem)[1];

    $dir = $tabela."/";
    if (!is_dir($dir)) {
        mkdir($dir, 0777, true);
    }

    $data = new DateTime();
    $data = $data->format('YmdHis');

    $name = $dir.$idcampo."_".$data.".".$extensao;
    $file = fopen($name, 'w');
    fwrite($file, base64_decode($base64));
    fclose($file);

    return $name;
}

function url_origin( $s, $use_forwarded_host = false )
{
    $ssl      = true; //( ! empty( $s['HTTPS'] ) && $s['HTTPS'] == 'on' );
    $sp       = strtolower( $s['SERVER_PROTOCOL'] );
    $protocol = substr( $sp, 0, strpos( $sp, '/' ) ) . ( ( $ssl ) ? 's' : '' );
    $port     = $s['SERVER_PORT'];
    $port     = ( ( $port=='80' ) || ( $port=='443' ) ) ? '' : ':'.$port;
    $host     = ( $use_forwarded_host && isset( $s['HTTP_X_FORWARDED_HOST'] ) ) ? $s['HTTP_X_FORWARDED_HOST'] : ( isset( $s['HTTP_HOST'] ) ? $s['HTTP_HOST'] : null );
    $host     = isset( $host ) ? $host : $s['SERVER_NAME'] . $port;
    return $protocol . '://' . $host;
}

function full_url( $s, $use_forwarded_host = false )
{
	$request = explode("/", $s['REQUEST_URI']);
	$request[count($request)-1] = "";
    return url_origin( $s, $use_forwarded_host ) . join('/', $request);
}

$url = full_url( $_SERVER );

?>