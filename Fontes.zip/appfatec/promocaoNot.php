<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("conexao.php");

$_POST = json_decode(file_get_contents('php://input'), true);
mysqli_query($con, "SET NAMES 'utf8'"); 
mysqli_query($con, "SET CHARACTER SET 'utf8'");

// $inicio = $_POST["inicio"];
// $fim = $_POST["fim"];

$query = "SELECT * FROM promocao where ativo = 1 and notificado = 0 order by id desc"; //limit $inicio, $fim
$sql= mysqli_query($con, $query);
$data = array();
while ($result =  mysqli_fetch_array($sql, MYSQLI_ASSOC))
{
    $atualiza = "UPDATE promocao set notificado = 1 where id = ".$result["id"]."";
    mysqli_query($con, $atualiza);
    array_push($data, array(
        'id' => $result['id'], 
        'titulo' => $result['titulo']
      
    ));
}

echo json_encode($data);
mysqli_close($con);

?>