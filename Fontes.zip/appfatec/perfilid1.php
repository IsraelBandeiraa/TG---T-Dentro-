<?php
header("Access-Control-Allow-Origin: *");
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("conexao.php");
$_POST = json_decode(file_get_contents('php://input'), true);
    $id = $_POST["id"];
   
    $sql = "select * from pessoa where id = '$id'";
    mysqli_query($con, "SET CHARACTER SET 'utf8'"); 
    $consulta =  mysqli_query($con,$sql);
    $resultado = mysqli_fetch_assoc($consulta);
   if($resultado["id"] > 0)
   {
    echo json_encode($resultado);
   }
   
mysqli_close($con);
