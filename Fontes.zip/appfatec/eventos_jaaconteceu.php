<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include "conexao.php";

$_POST = json_decode(file_get_contents('php://input'), true);
$id = $_POST["id"];
mysqli_query($con, "SET NAMES 'utf8'");
mysqli_query($con, "SET CHARACTER SET 'utf8'");
//$query = "SELECT * FROM evento WHERE status = 1 AND data >= CURRENT_DATE ORDER BY data ASC";
$query = "SELECT
            ev.*,
            (SELECT COUNT(*) FROM posevento WHERE eventoid = ev.id) AS posevento
            FROM
            evento AS ev,
            (SELECT
                lide,
                lidefuturo,
                lidemulher
              FROM
                pessoa
              WHERE
                id = '$id') AS li
            WHERE
            ev.status = 1
            AND ev.data < SUBDATE(CURRENT_DATE, INTERVAL 30 DAY)
            AND (ev.lide = li.lide
              OR ev.lidefuturo = li.lidefuturo
              OR ev.lidemulher = li.lidemulher)
            ORDER BY
            ev.data DESC,ev.hora DESC";

$sql = mysqli_query($con, $query);
$data = array();

while ($result = mysqli_fetch_array($sql, MYSQLI_ASSOC)) {
  array_push($data, array(
    'id' => $result['id'],
    'nome' => $result['nome'],
    'imagem' => $result['imagem'],
    'endereco' => $result['endereco'],
    'status' => $result['status'],
    'data' => $result['data'],
    'hora' => $result['hora'],
    'lat' => $result['latitude'],
    'long' => $result['longitude'],
    'lide' => $result['lide'],
    'lidefuturo' => $result['lidefuturo'],
    'lidemulher' => $result['lidemulher'],
    'posevento' => $result['posevento'],
    'descricao' => '',
  ));
}
echo json_encode($data);

mysqli_close($con);
