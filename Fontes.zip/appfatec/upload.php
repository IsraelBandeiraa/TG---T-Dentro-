<?php
require("conexao.php");
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
$foto = $_FILES["Filedata"];

	// Se a foto estiver sido selecionada
	if (!empty($foto["name"])) {

		// Largura máxima em pixels
		$largura = 1000000000000;
		// Altura máxima em pixels
		$altura = 1000000000000;
		// Tamanho máximo do arquivo em bytes
		$tamanho = 10000000000;

		// Pega as dimensões da imagem
		$dimensoes = getimagesize($foto["tmp_name"]);

		// Verifica se a largura da imagem é maior que a largura permitida
		if($dimensoes[0] > $largura) {
			$error[2] = "A largura da imagem não deve ultrapassar ".$largura." pixels";
		}

		// Verifica se a altura da imagem é maior que a altura permitida
		if($dimensoes[1] > $altura) {
			$error[3] = "Altura da imagem não deve ultrapassar ".$altura." pixels";
		}

		// Verifica se o tamanho da imagem é maior que o tamanho permitido
		if($foto["size"] > $tamanho) {
   		 	$error[4] = "A imagem deve ter no máximo ".$tamanho." bytes";
		}

		// Se não houver nenhum erro

			// Pega extensão da imagem
			preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $foto["name"], $ext);

        	// Gera um nome único para a imagem
        	$nome_imagem = md5(uniqid(time())) . "." . $ext[1];

        	// Caminho de onde ficará a imagem
        	$caminho_imagem = "../imagem/" . $nome_imagem;
            //$caminho_imagem = "../../Content/Imagens/" . $nome_imagem;
            
			// Faz o upload da imagem para seu respectivo caminho
			move_uploaded_file($foto["tmp_name"], $caminho_imagem);
			
			$sql = "insert into foto (arquivo)values('$caminho_imagem')";
            mysqli_query($con, $sql);            
            $sql1 = "select id from imagem where id = LAST_INSERT_ID()";    
            $consulta =  mysqli_query($con,$sql1);
            $resultado = mysqli_fetch_assoc($consulta);
            echo json_encode($resultado);
            echo $foto ;
	}
?>
