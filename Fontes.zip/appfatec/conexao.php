<?php

//$con = mysqli_connect("mysql.clientestotvssm.com.br", "Usuário", "Senha", "Banco");
$con = mysqli_connect("mysql.clientestotvssm.com.br", "clientestotvss02", "qS6fjohFUH9Y", "clientestotvss02");
mysqli_set_charset($con, "utf8");

mysqli_query($con, "SET NAMES 'utf8'");
mysqli_query($con, "SET CHARACTER SET 'utf8'");

?> 

 