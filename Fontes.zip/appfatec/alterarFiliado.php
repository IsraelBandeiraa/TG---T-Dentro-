<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$_POST = json_decode(file_get_contents('php://input'), true);

$iduser = $_POST["iduser"];
$tipo = $_POST["tipo"];
$dados = $_POST["dados"];

if(($iduser === null) || ($iduser === "")){
    $retorno = array('success' => false,'message'=>'Usuário não foi definido.');
    echo json_encode($retorno);
    return;
}

if(($tipo === null) || ($tipo === "")){
    $retorno = array('success' => false,'message'=>'Tipo operação não foi definido.');
    echo json_encode($retorno);
    return;
}

include("conexao.php");

if($tipo == "INSERT"){

    $sqlCampos = "";
    $sqlValores = "";
    foreach ($dados as $key => $valor) {
        if($sqlValores != ""){
            $sqlCampos = "$sqlCampos,$key";
            $sqlValores = "$sqlValores,'$valor'";
        }else{
            $sqlCampos = "$key";
            $sqlValores = "'$valor'";
        }
    }
    
    $sql = "INSERT INTO pessoa($sqlCampos) values($sqlValores)";
    $consulta = mysqli_query($con, $sql);
    if($consulta){
        $retorno = array('success' => true,'message'=>'Filiado cadastrado com sucesso.');
    }else{
        $retorno = array('success' => false,'message'=>"Erro ao cadastrar Filiado. #1. $sql - Erro:".mysqli_error($con));
    }

}else if($tipo == "UPDATE"){

    $sqlValores = "";
    foreach ($dados as $key => $valor) {
        if($sqlValores != ""){
            $sqlValores = "$sqlValores,$key='$valor'";
        }else{
            $sqlValores = "$key='$valor'";
        }
    }

    $sql = "UPDATE pessoa SET $sqlValores WHERE id = $iduser";
    $consulta = mysqli_query($con, $sql);
    if($consulta){
        $retorno = array('success' => true,'message'=>'Filiado alterado com sucesso.');
    }else{
        $retorno = array('success' => false,'message'=>"Erro ao alterar Filiado. #2. $sql - Erro:".mysqli_error($con));
    }    

}else if($tipo == "DELETE"){

    $sql = "DELETE FROM pessoa WHERE id = $iduser";
    $consulta = mysqli_query($con, $sql);
    if($consulta){
        $retorno = array('success' => true,'message'=>'Filiado deletado com sucesso.');
    }else{
        $retorno = array('success' => false,'message'=>'Erro ao deletar Filiado. #3');
    }    

}else{
    $retorno = array('success' => false,'message'=>'Tipo operação informado não é permitida. #4');
}

mysqli_close($con);

echo json_encode($retorno);

?>