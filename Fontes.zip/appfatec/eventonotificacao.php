<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("conexao.php");
   
mysqli_query($con, "SET NAMES 'utf8'"); 
mysqli_query($con, "SET CHARACTER SET 'utf8'"); 
$lide = $_GET["lide"];
$lideFuturo = $_GET["lidefuturo"];
if($lide == 1  && $lideFuturo == 0)
{
    $query = "select * from evento where status = 1 and lide = 1 and notificado = 0 order by data asc";
}
else if($lide == 0  && $lideFuturo == 1)
{
    $query = "select * from evento where status = 1 and lidefuturo = 1 and notificado = 0 order by data asc";
}

else{

    $query = "select * from evento where status = 1 and notificado = 0 order by data asc";

}


$sql= mysqli_query($con, $query);
$data = array();
while ($result =  mysqli_fetch_array($sql, MYSQLI_ASSOC))
{
$atualiza = "update evento set notificado = 1 where id = ".$result["id"]."";
$vai = mysqli_query($con, $atualiza);

array_push($data, array('id' => $result['id'], 
	'nome' => $result['nome'], 
	));

}
echo json_encode($data);


mysqli_close($con);

?>