<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$_POST = json_decode(file_get_contents('php://input'), true);

$idEvento = $_POST['idevento'];
$data = $_POST['data'];

if(($idEvento === null) || ($idEvento === "")){
  $retorno = array('erro'=>'Evento não informado.');
  echo json_encode($retorno);
  return;
}

$filtroData = "";
if(($data != null) && ($data != "")){
  $filtroData = " AND c.confirmardatahora BETWEEN '$data 00:00:00' AND '$data 23:59:59' ";
}

include("conexao.php");

$data = array();

$query = "SELECT
  (SELECT COUNT(*) FROM pessoa p WHERE ( ((e.lide = 1) AND (e.lide = p.lide)) OR ((e.lidefuturo = 1) AND (e.lidefuturo = p.lidefuturo)) OR ((e.lidemulher = 1) AND (e.lidemulher = p.lidemulher)) )) total,
  (SELECT COUNT(*) FROM checkin c,pessoa p WHERE c.iduser = p.id AND p.teste <> 1 AND c.idevento = e.id AND confirmar = 0 AND checkin = 0 AND checkout = 0 $filtroData) naocomparecera,
  (SELECT COUNT(*) FROM checkin c,pessoa p WHERE c.iduser = p.id AND p.teste <> 1 AND c.idevento = e.id AND confirmar = 1 AND checkin = 0 AND checkout = 0 $filtroData) comparecera,
  (SELECT COUNT(*) FROM checkin c,pessoa p WHERE c.iduser = p.id AND p.teste <> 1 AND c.idevento = e.id AND checkin = 1 AND checkout = 0 $filtroData) checkin,
  (SELECT COUNT(*) FROM checkin c,pessoa p WHERE c.iduser = p.id AND p.teste <> 1 AND c.idevento = e.id AND checkin = 1 AND checkout = 1 $filtroData) checkout
  FROM evento e
  WHERE id = $idEvento";
$sql= mysqli_query($con, $query);
while ($result =  mysqli_fetch_array($sql, MYSQLI_ASSOC))
{
  $data["estatistica"] = $result;
}

$lista = array();

$query = "SELECT p.nome,p.email,p.empresa,p.lide,p.lidefuturo,p.patrocinador,c.* FROM checkin c,pessoa p WHERE c.iduser = p.id AND p.teste <> 1 AND idevento = $idEvento $filtroData";
$sql= mysqli_query($con, $query);
while ($result =  mysqli_fetch_array($sql, MYSQLI_ASSOC))
{
  array_push($lista, $result);;
}
$data["lista"] = $lista;

mysqli_close($con);

echo json_encode($data);

?>
