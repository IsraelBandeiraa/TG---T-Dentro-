<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$_POST = json_decode(file_get_contents('php://input'), true);

include("pagante.php");
include("conexao.php");
include("notificacao.php");

$iduser = $_POST["iduser"];
$idevento = $_POST["idevento"];
$idpatrocinador = $_POST["idpatrocinador"];

try {
    $sql = "DELETE FROM checkin WHERE  iduser = '$iduser' AND idevento = '$idevento' AND id_patrocinador = '$idpatrocinador'";
    $consulta =  mysqli_query($con, $sql);
    $retorno = array('success' => true, 'message' => "Convidado excluído com sucesso.", 'sql' => "DELETE FROM checkin WHERE  iduser = '$iduser' AND idevento = '$idevento' AND id_patrocinador = '$idpatrocinador'");
    echo json_encode($retorno);
} catch (Exception $e) {
    mysqli_close($con);
    $retorno = array('success' => false, 'message' => 'Exceção capturada: ' .  $e->getMessage());
    echo json_encode($retorno);
}

mysqli_close($con);