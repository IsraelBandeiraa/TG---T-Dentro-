<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include "conexao.php";

$_POST = json_decode(file_get_contents('php://input'), true);
mysqli_query($con, "SET NAMES 'utf8'");

$idquiz = $_POST['idquiz'];
$idusuario = $_POST['idusuario'];

$quizrespondido = false;

$query = "SELECT id,titulo,enviounico,editar FROM quiz WHERE id = '$idquiz'";
$sql = mysqli_query($con, $query);
$data = array();
while ($result = mysqli_fetch_array($sql, MYSQLI_ASSOC)) {
    $quizid = $result['id'];

    $queryP = "SELECT id,quizid,pergunta,tiporesposta,editar FROM quizpergunta WHERE quizid = '$quizid' ORDER BY ordem";
    $sqlP = mysqli_query($con, $queryP);
    $perguntas = array();
    while ($resultP = mysqli_fetch_array($sqlP, MYSQLI_ASSOC)) {
        $perguntaid = $resultP['id'];

        $respostas = array();
        $respondido = false;

        $queryA = "SELECT id,quizperguntaid,descricao FROM quizalternativa WHERE quizperguntaid = '$perguntaid' ORDER BY ordem";
        $sqlA = mysqli_query($con, $queryA);
        $alternativas = array();
        while ($resultA = mysqli_fetch_array($sqlA, MYSQLI_ASSOC)) {

            array_push($alternativas, array(
                'id' => $resultA['id'],
                'quizperguntaid' => $resultA['quizperguntaid'],
                'descricao' => $resultA['descricao'],
            ));
            if ($resultP['tiporesposta'] == "MULTIPLAESCOLHA") {
                $respostas[$resultA['id']] = array(
                    'id' => '',
                    'resposta' => false,
                );
            }
        }

        $queryR = "SELECT id,resposta FROM quizresposta WHERE quizperguntaid = '$perguntaid' AND usuarioid = '$idusuario'";
        $sqlR = mysqli_query($con, $queryR);
        while ($resultR = mysqli_fetch_array($sqlR, MYSQLI_ASSOC)) {

            $respondido = true;
            if ($resultP['tiporesposta'] == "MULTIPLAESCOLHA") {
                $respostas[$resultR['resposta']] = array(
                    'id' => $resultR['id'],
                    'resposta' => true,
                );
            } else {
                $respostas[$resultP['id']] = array(
                    'id' => $resultR['id'],
                    'resposta' => $resultR['resposta'],
                );
            }
            
        }
        if (!$respondido) {
            $cor = "#f53d3d";
            $respostas[$resultP['id']] = array(
                'id' => '',
                'resposta' => '',
            );
        }else{
            $quizrespondido = true;
            $cor = "#f5aaaa";
        }

        array_push($perguntas, array(
            'id' => $resultP['id'],
            'quizid' => $resultP['quizid'],
            'pergunta' => $resultP['pergunta'],
            'tiporesposta' => $resultP['tiporesposta'],
            'editar' => ($resultP['editar'] == "1"),
            'alternativas' => $alternativas,
            'respostas' => $respostas,
            'respondido' => $respondido,
            'cor' => $cor
        ));

    }

    $data = array(
        'id' => $result['id'],
        'titulo' => $result['titulo'],
        'perguntas' => $perguntas,
        'enviounico' => ($result['enviounico'] == "1"),
        'editar' => ($result['editar'] == "1"),
        'respondido' => $quizrespondido
    );

}

echo json_encode($data);

mysqli_close($con);

?>