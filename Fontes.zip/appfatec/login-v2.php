<?php
header("Access-Control-Allow-Origin: *");
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("imagem.php");
include("conexao.php");
include("notificacao.php");
$_POST = json_decode(file_get_contents('php://input'), true);
$login = $_POST["usuario"];
$senha = $_POST["senha"];

$sql = "select * from pessoa where email = '$login' and senha = '$senha' and (acessoApp = 1 OR admin = 1)";
mysqli_query($con, "SET CHARACTER SET 'utf8'");

$consulta = mysqli_query($con, $sql);
$resultado = mysqli_fetch_assoc($consulta);
$imagem = $resultado['imagem'];
if(!(substr($imagem, 0, 10) == "data:image")){
    $resultado['imagem'] = $url . $imagem;
}

if ($resultado["id"] > 0) {
    if($resultado["status"] == "1"){
        $retorno = array('success' => true,'message'=>'','usuario'=>$resultado);

        if($resultado['primeirologin'] == "0"){
            enviarNotificacao($con,"BOASVINDAS",$resultado["id"],"",null);
        }
    }else{
        $retorno = array('success' => false,'message'=>'Usuário bloqueado, por favor aguarde aprovação','usuario'=>'');
    }
} else {

    $name = "zlog_falha_login.txt";
    $text = "$sql\n";
    $file = fopen($name, 'a');
    fwrite($file, $text);
    fclose($file);

    $retorno = array('success' => false,'message'=>'Usuário ou senha inválidos!','usuario'=>'');
}

mysqli_close($con);

echo json_encode($retorno);
