<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

include("conexao.php");

$_POST = json_decode(file_get_contents('php://input'), true);

$eventoid = $_POST["eventoid"];

if(($eventoid === null) || ($eventoid === "")){
    $retorno = array('success' => false,'message'=>'Evento não foi definido.');
    echo json_encode($retorno);
    return;
}

$sql = "SELECT * FROM eventosetor WHERE eventoid = $eventoid";
$consulta =  mysqli_query($con,$sql);
$data = array();
while ($result =  mysqli_fetch_array($consulta, MYSQLI_ASSOC))
{
    array_push($data, array(
            'id' => $result['id'], 
        	'eventoid' => $result['eventoid'],
            'nome' => $result['nome'], 
            'cor' => $result['cor'],
            'vagas' => $result['vagas']
    ));
}

mysqli_close($con);

$retorno = array('success' => true,'dados'=>$data);
echo json_encode($retorno);

?>