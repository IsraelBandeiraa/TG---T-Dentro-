<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$_POST = json_decode(file_get_contents('php://input'), true);
include "conexao.php";
include "notificacao.php";

$senderid = $_POST["senderid"];
$receiverid = $_POST["receverid"];
$mensagem = $_POST["mensagem"];

$sql = "insert into chat (senderid, receverid, mensagem, data, lido, userid) values ('$senderid','$receiverid','$mensagem', CURRENT_DATE, 0, '$senderid')";
echo $sql."\n";

$ret = enviarNotificacao($con,"NOVOCHAT",$senderid,"",array('receiverid' => $receiverid,'mensagem' => $titulo));

echo json_encode($ret)."\n";

mysqli_query($con, $sql);

mysqli_close($con);

?>