<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("conexao.php");
$_POST = json_decode(file_get_contents('php://input'), true);
$id = $_POST["id"];   
mysqli_query($con, "SET NAMES 'utf8'"); 
mysqli_query($con, "SET CHARACTER SET 'utf8'"); 
$query = "select evento.id, evento.nome, evento.descricao, evento.data, evento.latitude, evento.longitude, evento.status, 
evento.endereco, evento.data, evento.imagem, checkin.id as idcheckin from evento 
inner join checkin on checkin.idevento = evento.id 
where checkin.checkin = 1 and confirmar = 1 and checkin.iduser = '$id'  and checkin.checkout = 0";
$sql= mysqli_query($con, $query);
//$data = array();
// while ($result =  mysqli_fetch_array($sql, MYSQLI_ASSOC))
// {
// array_push($data, array('id' => $result['id'], 
// 	'nome' => $result['nome'], 
// 	'imagem' => $result['imagem'],
// 	 'endereco' => $result['endereco'], 
// 	 'status' => $result['status'],
// 	 'data' => $result['data'],
//      'descricao' => $result['descricao'],
// 	'idcheckin' => $result['idcheckin'],
// 	'checkin' => 1,
// 	'checkout' => 0
// ));

//}
//echo json_encode($data);


mysqli_close($con);

?>