<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
$_POST = json_decode(file_get_contents('php://input'), true);
include("conexao.php");
$id = $_POST["id"];
$evento = $_POST["evento"];
$sql = "SELECT * FROM checkin where idevento = $evento and iduser = $id";

$consulta =  mysqli_query($con,$sql);
$resultado = mysqli_fetch_assoc($consulta);
echo json_encode($resultado);
mysqli_close($con);
?>