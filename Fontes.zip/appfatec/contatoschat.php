<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("conexao.php");

$_POST = json_decode(file_get_contents('php://input'), true);
mysqli_query($con, "SET NAMES 'utf8'"); 
mysqli_query($con, "SET CHARACTER SET 'utf8'");
$id = $_POST["id"];
$query = "SELECT id, nome, cargo, empresa, lide, lidefuturo,imagem
 from pessoa where id in(select idcontato from contato where userid = $id and aceito = 1)
 or id in (select userid from contato where idcontato = $id and aceito = 1)";
$sql= mysqli_query($con, $query);
$data = array();
while ($result =  mysqli_fetch_array($sql, MYSQLI_ASSOC))
{
    $vida = "SELECT COUNT(id) as contar from chat where receverid = '$id' and senderid = '".$result['id']."' and lido = 0";
     $teste = mysqli_query($con, $vida);
     $trem = mysqli_fetch_array($teste, MYSQLI_ASSOC);
     $a = "select IFNULL((select data from chat where receverid = '$id' and senderid = '".$result['id']."' order by data desc limit 1), '0000-00-00') as data";
     $b =  mysqli_query($con, $a);
     $k =  mysqli_fetch_array($b, MYSQLI_ASSOC);

    array_push($data, array(
        'id' => $result['id'], 
        'nome' => $result['nome'], 
        'cargo' => $result['cargo'],
        'empresa' => $result['empresa'],
        'lide' => $result['lide'],
        'lidefuturo' => $result['lidefuturo'],
        'imagem' => $result['imagem'],
        'naolidos' => $trem['contar'],
        'ultimo' => $k["data"]
    ));
}

echo json_encode($data);
mysqli_close($con);

?>