<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

include "pagante.php";

$_POST = json_decode(file_get_contents('php://input'), true);

if (($_GET["e"] === null) || ($_GET["e"] === "")) {
    $retorno = array('success' => false, 'message' => 'Evento não foi definido.');
    echo json_encode($retorno);
    return;
}

if (($_GET["i"] === null) || ($_GET["i"] === "")) {
    $retorno = array('success' => false, 'message' => 'Impressora não foi definida.');
    echo json_encode($retorno);
    return;
}

if (($_POST["iduser"] === null) || ($_POST["iduser"] === "")) {
    $retorno = array('success' => false, 'message' => 'Usuário não foi informado.');
    echo json_encode($retorno);
    return;
}

$iduser = $_POST["iduser"];
$idevento = $_GET["e"];
$idimpressora = $_GET["i"];
$lat = 0;
$long = 0;
$nome = "Sem Nome";

if ($iduser != "") {
    include "conexao.php";

    $sqlNome = "SELECT nome FROM pessoa WHERE id = $iduser";
    $consultaNome = mysqli_query($con, $sqlNome);
    if ($resultadoNome = mysqli_fetch_assoc($consultaNome)) {
        $nome = $resultadoNome["nome"];
    }

    $retorno = array('success' => false, 'message' => 'Erro não identificado.', 'nome' => $nome);

    $sql = "SELECT c.id,c.checkin,c.checkout,c.confirmar,c.confirmoumanual,c.pagante,TIMEDIFF(NOW(), CONCAT(e.data,' ',e.hora)) tempo FROM checkin c,evento e WHERE c.idevento = e.id AND e.id = $idevento AND c.iduser = $iduser";
    $consulta = mysqli_query($con, $sql);
    if ($resultado = mysqli_fetch_assoc($consulta)) { //Verifica se confirmou presença
        $idcheck = $resultado["id"];

        if ($resultado["pagante"] == 1) {
            // O Filiado está confirmado no evento e foi registrado como pagante
            $retorno = array('success' => false, 'message' => 'Check-in NÃO realizado, por favor procure a organização.', 'nome' => $nome);
        } else {

            $tempo = explode(":", $resultado["tempo"]);

            if (($resultado["checkin"] == 0) || ($tempo[0] < 2)) {

                $sql = "UPDATE checkin SET checkin = 1,checkindatahora = NOW() WHERE id = $idcheck";
                $consulta = mysqli_query($con, $sql);
                if ($consulta) {
                    $retorno = array('success' => true, 'message' => 'Check-in realizado com sucesso.', 'nome' => $nome);

                    $sql = "INSERT INTO imprimir(idevento, idpessoa, impressora) values($idevento, $iduser, $idimpressora)";
                    $consulta = mysqli_query($con, $sql);

                    $name = "zlog_impressao_e_" . $idevento . "_i_" . $idimpressora . ".txt";
                    $text = "$iduser\n";
                    $file = fopen($name, 'a');
                    fwrite($file, $text);
                    fclose($file);
                } else {
                    $retorno = array('success' => false, 'message' => 'Erro ao realizar check-in. #1', 'nome' => $nome);
                }
            } else {
                if ($resultado["checkout"] == 0) {
                    $sql = "UPDATE checkin SET checkin = 1,checkout = 1,checkoutdatahora = NOW() WHERE id = $idcheck";
                    $consulta = mysqli_query($con, $sql);
                    if ($consulta) {
                        $retorno = array('success' => true, 'message' => 'Check-out realizado com sucesso.', 'nome' => $nome);
                    } else {
                        $retorno = array('success' => false, 'message' => 'Erro ao realizar check-in. #2', 'nome' => $nome);
                    }
                } else {
                    $retorno = array('success' => false, 'message' => 'Check-out já realizado.', 'nome' => $nome);
                }
            }
        }
    } else {
        //Se não fez confirmou, verifica se ele pode entrar pelo evento.
        $acesso = temAcesso($con, $iduser, $idevento);
        if ($acesso) {

            $pagante = isPagante($con, $idusuario, $idevento);
            if (!$pagante) {

                $podeRegistrar = false;
                $confirmados = 0;
                $vagas = 0;

                $sqlConf = "SELECT COUNT(*) confirmados FROM checkin WHERE idevento = '$idevento' AND confirmar = 1";
                $consultaConf = mysqli_query($con, $sqlConf);
                if ($resultadoConf = mysqli_fetch_assoc($consultaConf)) {
                    $confirmados = $resultadoConf["confirmados"];
                }

                $sqlVagas = "SELECT vagas FROM evento WHERE id = '$idevento'";
                $consultaVagas = mysqli_query($con, $sqlVagas);
                if ($resultadoVagas = mysqli_fetch_assoc($consultaVagas)) {
                    $vagas = $resultadoVagas["vagas"];
                }

                if (($vagas == 0) || ($confirmados < $vagas)) {

                    $sql = "INSERT INTO checkin(idevento, iduser, latitude, longitude, confirmar,confirmoumanual, checkin, checkout,confirmardatahora,checkindatahora,checkoutdatahora) values($idevento, $iduser, $lat, $long, 1,1,1,0,NOW(),NOW(),NOW())";
                    $consulta = mysqli_query($con, $sql);
                    if ($consulta) {
                        $retorno = array('success' => true, 'message' => 'Check-in realizado com sucesso.', 'nome' => $nome);

                        $sql = "INSERT INTO imprimir(idevento, idpessoa, impressora) values($idevento, $iduser, $idimpressora)";
                        $consulta = mysqli_query($con, $sql);

                        $name = "zlog_impressao_e_" . $idevento . "_i_" . $idimpressora . ".txt";
                        $text = "$iduser\n";
                        $file = fopen($name, 'a');
                        fwrite($file, $text);
                        fclose($file);
                    } else {
                        $retorno = array('success' => false, 'message' => 'Erro ao realizar check-in. #3', 'nome' => $nome);
                    }
                } else {

                    $retorno = array('success' => false, 'message' => 'Check-in NÃO realizado, VAGAS ESGOTADAS, por favor procure a organização.', 'nome' => $nome);
                }
            } else {
                $retorno = array('success' => false, 'message' => 'Check-in NÃO realizado, por favor procure a organização.', 'nome' => $nome);
            }
        } else {
            $retorno = array('success' => false, 'message' => 'Check-in NÃO realizado pois o filiado NÃO confirmou, por favor procure a organização.', 'nome' => $nome);
        }
    }

    mysqli_close($con);

    echo json_encode($retorno);
} else {
    $retorno = array('success' => false, 'message' => 'Usuário não informado.', 'nome' => $nome);
    echo json_encode($retorno);
}
