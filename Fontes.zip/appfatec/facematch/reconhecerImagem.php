<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$_POST = json_decode(file_get_contents('php://input'), true);

$img64 = $_POST["img64"];

if(($img64 === null) || ($img64 === "")){
    $retorno = array('success' => false,'message'=>'Imagem não enviada.');
    echo json_encode($retorno);
    return;
}

$url = "http://totvsrp.com.br:8993";
$session = "";

echo "############ TESTE4";

$ch = curl_init();
 
//Set the URL that you want to GET by using the CURLOPT_URL option.
curl_setopt($ch, CURLOPT_URL, 'http://google.com');
 
//Set CURLOPT_RETURNTRANSFER so that the content is returned as a variable.
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 
//Set CURLOPT_FOLLOWLOCATION to true to follow redirects.
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
 
//Execute the request.
$data = curl_exec($ch);
 
//Close the cURL handle.
curl_close($ch);
 
//Print the data out onto the page.
echo $data;

echo "############ NOVO TESTE2";

$service_url = 'http://google.com';
$curl = curl_init($service_url);
$curl_response = curl_exec($curl);
curl_close($curl);

echo $curl_response;

echo "################response";



// $r = new HttpRequest("$url/session?id=admin&auth=YWRtaW46MTIz", HttpRequest::METH_GET);
// try {
//     $r->send();
//     if ($r->getResponseCode() == 200) {
//         $jsonRetorno =  json_decode($r->getResponseBody(), true);
//         if($jsonRetorno["result"] == "success"){
//             $session = $jsonRetorno["session"];
//         }else{
//             $code = $jsonRetorno["code"];
//             $reason = $jsonRetorno["reason"];
//             $retorno = array('success' => false,'message'=>"Erro ao pegar a session code: $code reason: $reason");
//             echo json_encode($retorno);
//             return;            
//         }
//     }else{
//         $retorno = array('success' => false,'message'=>'Erro ao efetuar login. Status Code: '.$r->getResponseCode());
//         echo json_encode($retorno);
//         return;        
//     }
// } catch (HttpException $ex) {
//     echo $ex;
// }

// $HTTPRequest = new HTTPRequest();
// $HTTPRequest->getHTTPObject();
// $HTTPRequest->setRequestTarget( new HTTPRequestTarget( "$url/session?id=admin&auth=YWRtaW46MTIz" ) );
// $HTTPRequest->setRequestMethod( 'GET' );
// $HTTPRequest->sendRequest();
// if( $HTTPRequest->getRequestStatus() == 200 ){
//     $jsonRetorno =  json_decode($HTTPRequest->getRequestOutput(), true);
//     if($jsonRetorno["result"] == "success"){
//         $session = $jsonRetorno["session"];
//     }else{
//         $code = $jsonRetorno["code"];
//         $reason = $jsonRetorno["reason"];
//         $retorno = array('success' => false,'message'=>"Erro ao pegar a session code: $code reason: $reason");
//         echo json_encode($retorno);
//         return;            
//     }
// }else{
//     $retorno = array('success' => false,'message'=>'Erro ao efetuar login. Status Code: '.$HTTPRequest->getRequestStatus());
//     echo json_encode($retorno);
//     return;
// }


$retorno = array('success' => true,'message'=>"Filiado reconhecido com sucesso. $session");
echo json_encode($retorno);
return;

include("conexao.php");

$retorno = array('success' => false,'message'=>'Erro não identificado.');

$sql = "SELECT id,checkin,checkout FROM checkin WHERE idevento = $idevento AND iduser = $iduser";
$consulta =  mysqli_query($con,$sql);
if($resultado = mysqli_fetch_assoc($consulta)){

    $sqlValores = "";
    foreach ($dados as $key => $valor) {
        if($sqlValores != ""){
            $sqlValores = "$sqlValores,$key=$valor";
        }else{
            $sqlValores = "$key='$valor'";
        }
    }

    $idcheck = $resultado["id"];

    $sql = "UPDATE checkin SET $sqlValores WHERE id = $idcheck";
    $consulta = mysqli_query($con, $sql);
    if($consulta){
        $retorno = array('success' => true,'message'=>'Ação realizada com sucesso.');

        if($imprimir == "1"){
            $sql = "INSERT INTO imprimir(idevento, idpessoa, impressora) values($idevento, $iduser, $idimpressora)";
            $consulta = mysqli_query($con, $sql);    
        }
    }else{
        $retorno = array('success' => false,'message'=>'Erro ao realizar ação. #1. Erro:'.mysqli_error($con));
    }    

}else{
    $dados['idevento'] = $idevento;
    $dados['iduser'] = $iduser;
    $dados['latitude'] = $lat;
    $dados['longitude'] = $long;
    if($confirmar == "0"){
        $dados['confirmar'] = '0';
    }
    if($checkin == "0"){
        $dados['checkin'] = '0';
    }
    if($checkout == "0"){
        $dados['checkout'] = '0';
    }

    $sqlCampos = "";
    $sqlValores = "";
    foreach ($dados as $key => $valor) {
        if($sqlValores != ""){
            $sqlCampos = "$sqlCampos,$key";
            $sqlValores = "$sqlValores,$valor";
        }else{
            $sqlCampos = "$key";
            $sqlValores = "'$valor'";
        }
    } 

    $sql = "INSERT INTO checkin($sqlCampos) values($sqlValores)";
    $consulta = mysqli_query($con, $sql);
    if($consulta){
        $retorno = array('success' => true,'message'=>'Ação realizada com sucesso.');

        if($imprimir == "1"){
            $sql = "INSERT INTO imprimir(idevento, idpessoa, impressora) values($idevento, $iduser, $idimpressora)";
            $consulta = mysqli_query($con, $sql);    
        }
    }else{
        $retorno = array('success' => false,'message'=>"Erro ao realizar check-in. #2. $sql Erro:".mysqli_error($con));
    }
}

mysqli_close($con);

echo json_encode($retorno);


?>