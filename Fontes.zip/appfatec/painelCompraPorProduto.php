<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("conexao.php");
include("imagem.php");

$_POST = json_decode(file_get_contents('php://input'), true);

$filiadoid = $_POST["filiadoid"];
$empresaid = $_POST["empresaid"];

$url = full_url($_SERVER);

$sql = "SELECT
        e.id idempresa,
        e.nome nomeempresa,
        e.descricao,
        e.patrocinador,
        p.id idproduto,
        p.nome
        FROM
        empresa e,
        empresa_produto ep,
        produto p
        WHERE
        ep.idempresa = e.id
        AND ep.idproduto = p.id
        AND gerentecomercial <> 0";
$consulta =  mysqli_query($con, $sql);
$resultadoEmpresa = array();
while ($resultado =  mysqli_fetch_array($consulta, MYSQLI_ASSOC)) {

    // $imagem = $resultado['foto'];
    // if (!(substr($imagem, 0, 10) == "data:image")) {
    //     $resultado['foto'] = $url . $imagem;
    // }

    array_push($resultadoEmpresa, $resultado);
}

mysqli_close($con);

$retorno = array('success' => true, 'dados' => $resultadoEmpresa);
echo json_encode($retorno);
