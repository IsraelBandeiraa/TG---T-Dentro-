<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("conexao.php");
include("imagem.php");

$_POST = json_decode(file_get_contents('php://input'), true);

$filiadoid = $_POST["filiadoid"];
$fornecedorid = $_POST["fornecedorid"];

$url = full_url($_SERVER);

$sql = "SELECT sc.*, p.nome, e.nome empresa_nome
        FROM solicitacao_compra sc
        JOIN pessoa p ON sc.filiado = p.id
        JOIN empresa e ON sc.comprador = e.id
        WHERE fornecedor = '$fornecedorid'";
$consulta =  mysqli_query($con, $sql);
$resultadoEmpresa = array();
while ($resultado =  mysqli_fetch_array($consulta, MYSQLI_ASSOC)) {
    array_push($resultadoEmpresa, $resultado);
}

mysqli_close($con);



$retorno = array(
    'success' => true,
    'dados' => $resultadoEmpresa
);
echo json_encode($retorno);
