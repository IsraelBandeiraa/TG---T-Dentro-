<?php

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$_POST = json_decode(file_get_contents('php://input'), true);
include("conexao.php");

$userid = $_POST["id"];
$token = $_POST["token"];
$plataformas = $_POST["plataformas"];

mysqli_query($con, "SET CHARACTER SET 'utf8'");

$sql = "SELECT id FROM pessoatoken WHERE token = '$token'";
$consulta = mysqli_query($con, $sql);
if ($resultado = mysqli_fetch_assoc($consulta)) {
    $idtoken = $resultado["id"];

    $sql = "UPDATE pessoatoken SET token = '$token',plataformas = '$plataformas',userid = '$userid' WHERE id = '$idtoken'";
    $consulta = mysqli_query($con, $sql);
    if ($consulta) {
        $retorno = array('success' => true, 'message' => 'Token registrado com sucesso.');
    } else {
        $retorno = array('success' => false, 'message' => 'Erro ao registrar token. #1');
    }

} else {
    $sql = "INSERT INTO pessoatoken(token,userid,plataformas) values('$token', '$userid', '$plataformas')";
    $consulta = mysqli_query($con, $sql);
    if ($consulta) {
        $retorno = array('success' => true, 'message' => 'Token registrado com sucesso.');
    } else {
        $retorno = array('success' => false, 'message' => 'Erro ao registrar token. #2');
    }
}

echo json_encode($retorno);

mysqli_close($con);

?>