<?php
header("Access-Control-Allow-Origin: *");
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("conexao.php");
$_POST = json_decode(file_get_contents('php://input'), true);
    $id = $_POST["id"];
  
    $sql = "select data, descricao, endereco,funcao, hora, id, imagem, latitude, longitude, lide, lidefuturo, 
    link, local, nome, organizador, palestrante as paleestrante, status
    from evento where id = '$id'";
    mysqli_query($con, "SET CHARACTER SET 'utf8'"); 
    $consulta =  mysqli_query($con,$sql);
    $resultado = mysqli_fetch_assoc($consulta);
    echo json_encode($resultado);
    mysqli_close($con);


?>