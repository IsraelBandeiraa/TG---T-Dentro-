<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$_POST = json_decode(file_get_contents('php://input'), true);

$tipo = $_POST["tipo"];
$usuarioid = $_POST["usuarioid"];
$eventoid = $_POST["eventoid"];

if(($tipo === null) || ($tipo === "")){
    $retorno = array('success' => false,'message'=>'Tipo operação não foi definido.');
    echo json_encode($retorno);
    return;
}

include("notificacao.php");
include("conexao.php");

$retorno = enviarNotificacao($con,$tipo,$usuarioid,$eventoid,$_POST);

echo json_encode($retorno);

mysqli_close($con);


?>