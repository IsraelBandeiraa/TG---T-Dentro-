<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$_POST = json_decode(file_get_contents('php://input'), true);
include "conexao.php";

$iduser = $_POST["iduser"];
$idevento = $_POST["idevento"];

if(($idevento === null) || ($idevento === "") || ($idevento == 0)){
    $retorno = array('success' => false,'message'=>'idevento não foi definido.');
    echo json_encode($retorno);
    return;
}

if(($iduser === null) || ($iduser === "")|| ($iduser == 0)){
    $retorno = array('success' => false,'message'=>'iduser não foi definido.');
    echo json_encode($retorno);
    return;
}

$sql = "UPDATE notificacaousuario SET lido = 1 WHERE tipo IN ('NOVOEVENTO','ALTERACAOEVENTO') AND userid = $iduser AND objetoid = $idevento";
$consulta = mysqli_query($con, $sql);
if ($consulta) {
    $retorno = array('success' => true, 'message' => 'Notificações marcadas como lida.');
} else {
    $retorno = array('success' => false, 'message' => 'Erro ao marcar notificações como lida. #1');
}

echo json_encode($retorno);

mysqli_close($con);

?>