<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$_POST = json_decode(file_get_contents('php://input'), true);

include("pagante.php");
include("conexao.php");
include("notificacao.php");

$iduser = $_POST["iduser"];
$idevento = $_POST["idevento"];
$lat = $_POST["lat"];
$long = $_POST["long"];
$confirmar = $_POST["confirmar"];
$email = $_POST["email"];
$nome = $_POST["nome"];
$evento = $_POST["evento"];
$data = $_POST["data"];
$hora = $_POST["hora"];
$idPatrocinador = $_POST["idPatrocinador"];
$obsConvidado = $_POST["obsConvidado"];
/*if ($confirmar != 0) {
    $confirmar = 1;
}*/

if (empty($idPatrocinador)) {
    $idPatrocinador = null;
}

if (empty($obsConvidado)) {
    $obsConvidado = "Convidado adicionado via APP.";
}

if (($iduser === null) || ($iduser === "")) {
    $retorno = array('success' => false, 'message' => 'Usuário não foi definido.');
    echo json_encode($retorno);
    return;
}

if (($email === null) || ($email === "")) {
    $retorno = array('success' => false, 'message' => 'E-mail não foi definido.');
    echo json_encode($retorno);
    return;
}

$podeRegistrar = false;
$confirmados = 0;
$vagas = 0;

$sqlConf = "SELECT COUNT(*) confirmados FROM checkin WHERE idevento = '$idevento' AND confirmar = 1";
$consultaConf = mysqli_query($con, $sqlConf);
if ($resultadoConf = mysqli_fetch_assoc($consultaConf)) {
    $confirmados = $resultadoConf["confirmados"];
}

$sqlVagas = "SELECT vagas, DATE_FORMAT(data, '%d/%m/%Y') data, hora, nome FROM evento WHERE id = '$idevento'";
$consultaVagas = mysqli_query($con, $sqlVagas);
if ($resultadoVagas = mysqli_fetch_assoc($consultaVagas)) {
    $vagas = $resultadoVagas["vagas"];
    $evento = $resultadoVagas["nome"];
    $data = $resultadoVagas["data"];
    $hora = $resultadoVagas["hora"];
}

if (($vagas == 0) || ($confirmar == 0) || ($confirmados < $vagas)) {
    try {
        mysqli_query($con, "SET CHARACTER SET 'utf8'");
        $caraio = "delete from checkin where  iduser = '$iduser' and idevento = '$idevento'";
        $consulta =  mysqli_query($con, $caraio);
        $pagante = isPagante($con, $iduser, $idevento);
        if ($idPatrocinador) {
            $sql =  "INSERT INTO checkin(idevento, iduser, latitude, longitude, confirmar, checkin, checkout,pagante,confirmardatahora, id_patrocinador, obsConvidado) values($idevento, $iduser, '$lat', '$long', $confirmar,0,0,$pagante,NOW(), $idPatrocinador, '$obsConvidado')";
        } else {
            $sql =  "INSERT INTO checkin(idevento, iduser, latitude, longitude, confirmar, checkin, checkout,pagante,confirmardatahora) values($idevento, $iduser, '$lat', '$long', $confirmar,0,0,$pagante,NOW())";
        }
        mysqli_query($con, $sql);

        $resposta = "";
        if ($confirmar == 0 || $confirmar == "0") {
            $resposta = "não irá comparecer ao Evento : " . $evento . ".";
        } else if ($confirmar == 1 || $confirmar == "1") {
            $resposta = "confirmou sua presença no Evento : " . $evento . ".";
        } else if ($confirmar == 2 || $confirmar == "2") {
            $resposta = "não sabe se irá comparecer ao Evento : " . $evento . ".";
        }

        $mensagem = " <html>
    
        <head>
            <meta charset='utf-8'>
            <title>Tô Dentro!</title>
        </head>
        
        <body lang='PT-BR' link='#0563C1' vlink='#954F72'>
            <div class='WordSection1'>
                <p class='MsoNormal'>
                    <img src='/admin-app-fatec/fatec_widelg.jpg'>
                </p>
                <p class='MsoNormal'>
                    <o:p>&nbsp;</o:p>
                </p>
                <h2 style='mso-margin-top-alt:15.0pt;margin-right:0cm;margin-bottom:7.5pt;margin-left:0cm'>
                    <span style='font-size:22.5pt;font-family:&quot;Calibri&quot;,sans-serif;color:#333333;font-weight:normal'>
                        Olá, $nome
                    </span>
                </h2>
                <p style='mso-margin-top-alt:0cm;margin-right:0cm;margin-bottom:7.5pt;margin-left:0cm;box-sizing: border-box'>
                    <span style='font-size:12.5pt;font-family:&quot;Calibri&quot;,sans-serif;color:#333333'>
                        Você $resposta
                    </span>
                </p>
                <p style='mso-margin-top-alt:0cm;margin-right:0cm;margin-bottom:7.5pt;margin-left:0cm;box-sizing: border-box'>
                    <span style='font-size:12.5pt;font-family:&quot;Calibri&quot;,sans-serif;color:#333333'>
                        Data: $data
                    </span>
                </p>
                <p style='mso-margin-top-alt:0cm;margin-right:0cm;margin-bottom:7.5pt;margin-left:0cm;box-sizing: border-box'>
                    <span style='font-size:12.5pt;font-family:&quot;Calibri&quot;,sans-serif;color:#333333'>
                        Hora: $hora
                    </span>
                </p>
                <p style='mso-margin-top-alt:0cm;margin-right:0cm;margin-bottom:7.5pt;margin-left:0cm;box-sizing: border-box'>
                    <span style='font-size:12.5pt;font-family:&quot;Calibri&quot;,sans-serif;color:#333333'>
                    
                    </span>
                </p>
                <p style='mso-margin-top-alt:0cm;margin-right:0cm;margin-bottom:7.5pt;margin-left:0cm;box-sizing: border-box'>
                    <span style='font-size:8.5pt;font-family:&quot;Calibri&quot;,sans-serif;color:#333333'>
                            Esta é uma mensagem automática.
                            <br />Por favor, não responda.
                      </span>
                </p>
            </div>
        </body>
        
        </html> ";

        $remetente = array('nome' => "Equipe Tô Dentro!");
        $destinatarios = array();
        array_push($destinatarios, array('email' => $email, 'nome' => $nome));
        $assunto = "Confirmação de Evento";
        $ishtml = true;

        enviarEmail($remetente, $destinatarios, $assunto, $mensagem, $ishtml);

        $resposta = "";
        if ($confirmar == 0 || $confirmar == "0") {
            $resposta = "Não comparecimento confirmado.";
        } else if ($confirmar == 1 || $confirmar == "1") {
            $resposta = "Presença CONFIRMADA com sucesso!";
        } else if ($confirmar == 2 || $confirmar == "2") {
            $resposta = "Resposta confirmada.";
        }

        $retorno = array('success' => true, 'message' => $resposta, 'sql' => $sql);
        echo json_encode($retorno);
    } catch (Exception $e) {
        mysqli_close($con);
        $retorno = array('success' => false, 'dados' => null, 'message' => 'Exceção capturada: ' .  $e->getMessage());
        echo json_encode($retorno);
    }
} else {

    $retorno = array('success' => false, 'message' => 'Sua presença NÃO foi confirmada, VAGAS ESGOTADAS.');
    echo json_encode($retorno);
}

mysqli_close($con);
