<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$_POST = json_decode(file_get_contents('php://input'), true);
include("conexao.php");
try {
    $nome = $_POST["nome"];
    $email = $_POST["email"];
    $senha = $_POST["senha"];
    $cargo = $_POST["cargo"];
    $cpf = $_POST["cpf"];
    $empresa = $_POST["empresa"];
    $lide = $_POST["lide"];
    $lidefuturo = $_POST["lidefuturo"];
    $compTel = $_POST["compTel"];
    $compTelSec     = $_POST["compTelSec"];
    $compEmail = $_POST["compEmail"];
    $compEmailSec = $_POST["compEmailSec"];
    $emailSec = $_POST["emailSec"];
    $site = $_POST["site"];
    $tel = $_POST["tel"];
    $telSec = $_POST["telSec"];
    $imagem = $_POST["imagem"];
    // $nascimento =$_POST["nascimento"];
    $segmento = $_POST["segmento"];


    $sqlC = "SELECT p.* FROM pessoa p WHERE p.email = '$email'";
    $consultaC =  mysqli_query($con, $sqlC);
    $resultadoC = mysqli_fetch_assoc($consultaC);

    if (count((is_countable($resultadoC) ? $resultadoC : [])) > 0) {
        $retornoC = array('success' => false, 'dados' => $resultadoC, 'message' => 'Já existe um cadastro para este e-mail.');
        echo json_encode($retornoC);
    } else {

        $sql = "insert into pessoa (nome, email, cpf, senha, cargo, empresa, lide, lidefuturo, compTel, compTelSec,
      compEmail, compEmailSec, emailSec, site, tel, telSec, imagem,  segmento, primeirologin)
      values ('$nome','$email', '$cpf','$senha','$cargo','$empresa','$lide','$lidefuturo','$compTel','$compTelSec',
      '$compEmail','$compEmailSec','$emailSec','$site','$tel','$telSec','$imagem','$segmento', 0)";

        mysqli_query($con, $sql);

        $sql1 = "select * from pessoa where id = LAST_INSERT_ID()";

        $consulta =  mysqli_query($con, $sql1);
        $resultado = mysqli_fetch_assoc($consulta);
        echo json_encode($resultado);
    }
} catch (Exception $e) {
    mysqli_close($con);
    $retorno = array('success' => false, 'message' => 'Exceção capturada: ' .  $e->getMessage());
    echo json_encode($retorno);
}

mysqli_close($con);


