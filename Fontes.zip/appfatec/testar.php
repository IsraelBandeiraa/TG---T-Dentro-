<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$_POST = json_decode(file_get_contents('php://input'), true);

include("conexao.php");

$idevento = $_POST["idevento"];

$idusuario = $_POST["idusuario"];

echo "Incluindo funcao\n";

include("pagante.php");

echo "idevento $idevento\n";
echo "idusuario $idusuario\n";
echo "Chamando funcao\n";

$query = "SELECT c.id checkin,p.id,p.nome,p.email,p.status,p.lide,p.lidefuturo,p.patrocinador,p.empresa,p.teste,c.pagante FROM pessoa p,evento e,checkin c WHERE c.idevento = e.id AND c.iduser = p.id AND e.id = $idevento";

$sql= mysqli_query($con, $query);
$data = array();
while ($result =  mysqli_fetch_array($sql, MYSQLI_ASSOC))
{
    $idusuario = $result['id'];
    $nome = $result['nome'];
    $pagante = isPagante($con,$idusuario,$idevento);

    if($pagante){
        echo "Pagante: $idusuario - $nome - ".$result['checkin'].' - '.$result['pagante'].' - '.$result['lide'].$result['lidefuturo']."\n";
    }
}

$pagante = isPagante($con,$idusuario,$idevento);

echo "Retorno funcao pagante: $pagante \n";

$acesso = temAcesso($con,$idusuario,$idevento);

echo "Retorno funcao acesso: $acesso \n";

mysqli_close($con);

// include("conexao.php");
   
//     $titulo = $_POST["titulo"];
//     $texto = $_POST["descricao"];
//     $aprovado = 1;
//     $iduser = "527";
//     $imagem = "";

//     $sql = "insert into post (iduser, titulo, texto, imagem, data, aprovado) values ('$iduser','$titulo','$texto', '$imagem', CURRENT_DATE, '$aprovado')";
    
//     echo $sql;
 
//     mysqli_query($con, $sql);

//     mysqli_close($con);


$retorno = array('titulo' => $titulo, 
                'descricao' => $descricao,
                'descricao2' => $descricao,
                'descricao3' => $descricao,
                'descricao4' => $descricao);


echo json_encode($retorno);

?>