<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("conexao.php");
   
$_POST = json_decode(file_get_contents('php://input'), true);

$idevento = $_POST["idevento"];
$iduser = $_POST["iduser"];

$query = "SELECT pessoa.nome as pessoanome, idevento, senderid, mensagem, chatevento.data as data, lido 
FROM chatevento
 inner join pessoa on senderid = pessoa.id 
 inner join evento on evento.id = chatevento.idevento where idevento = '$idevento' and senderid= '$iduser' order by chatevento.data asc";


$sql= mysqli_query($con, $query);
$data = array();
while ($result =  mysqli_fetch_array($sql, MYSQLI_ASSOC))
{
    array_push($data, array(
    'pessoanome' => utf8_encode($result['pessoanome']), 
    'idevento' => $result['idevento'],
    'senderid' => $result['senderid'],
    'mensagem' => $result['mensagem'],    
	'data' => $result['data'],
	'lido' => $result['lido'] 
	));

}
echo json_encode($data);


mysqli_close($con);

?>