<?php
header("Access-Control-Allow-Origin: *");
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("conexao.php");
include("notificacao.php");
$_POST = json_decode(file_get_contents('php://input'), true);
$login = $_POST["usuario"];

$sql = "select * from pessoa where email = '$login'";

mysqli_query($con, "SET CHARACTER SET 'utf8'");
$consulta = mysqli_query($con, $sql);
$resultado = mysqli_fetch_assoc($consulta);
if ($resultado["id"] > 0) {

    $iduser = $resultado["id"];
    $senha = rand(100000, 999999);

    $sql = "UPDATE pessoa SET senha = $senha WHERE id = $iduser";
    $consulta = mysqli_query($con, $sql);
    if ($consulta) {

        enviarSenha($resultado["nome"], $resultado["email"], $senha);

        $retorno = array('success' => true, 'message' => 'Nova senha enviada para o e-mail!');
    } else {

        $retorno = array('success' => false, 'message' => 'Problemas ao gerar uma nova senha!');
    }
} else {

    $retorno = array('success' => false, 'message' => 'Usuário não cadastrado!');
}

mysqli_close($con);

echo json_encode($retorno);

function enviarSenha($nome, $email, $senha)
{
    $mensagem = " <html>

    <head>
        <meta charset='utf-8'>
        <title>Tô Dentro!</title>
    </head>
    
    <body lang='PT-BR' link='#0563C1' vlink='#954F72'>
        <div class='WordSection1'>
            <p class='MsoNormal'>
                <img src=''>
            </p>
            <p class='MsoNormal'>
                <o:p>&nbsp;</o:p>
            </p>
            <h2 style='mso-margin-top-alt:15.0pt;margin-right:0cm;margin-bottom:7.5pt;margin-left:0cm'>
                <span style='font-size:22.5pt;font-family:&quot;Calibri&quot;,sans-serif;color:#333333;font-weight:normal'>
                    Olá, $nome
                </span>
            </h2>
            <p style='mso-margin-top-alt:0cm;margin-right:0cm;margin-bottom:7.5pt;margin-left:0cm;box-sizing: border-box'>
                <span style='font-size:12.5pt;font-family:&quot;Calibri&quot;,sans-serif;color:#333333'>
                    Sua nova senha para acessar o App foi gerada com sucesso!
                </span>
            </p>
            <p style='mso-margin-top-alt:0cm;margin-right:0cm;margin-bottom:7.5pt;margin-left:0cm;box-sizing: border-box'>
                <span style='font-size:12.5pt;font-family:&quot;Calibri&quot;,sans-serif;color:#333333'>
                    Email: $email
                </span>
            </p>
            <p style='mso-margin-top-alt:0cm;margin-right:0cm;margin-bottom:7.5pt;margin-left:0cm;box-sizing: border-box'>
                <span style='font-size:12.5pt;font-family:&quot;Calibri&quot;,sans-serif;color:#333333'>
                    Senha: $senha
                </span>
            </p>
            <p style='mso-margin-top-alt:0cm;margin-right:0cm;margin-bottom:7.5pt;margin-left:0cm;box-sizing: border-box'>
                <span style='font-size:8.5pt;font-family:&quot;Calibri&quot;,sans-serif;color:#333333'>
                        Esta é uma mensagem automática.
                        <br />Por favor, não responda.
                  </span>
            </p>
        </div>
    </body>
    
    </html> ";

    $remetente = array('nome' => "App LIDE By TOTVS");
    $destinatarios = array();
    array_push($destinatarios, array('email' => $email, 'nome' => $nome));
    $assunto = "Recuperação de senha APP LIDE";
    $ishtml = true;

    enviarEmail($remetente, $destinatarios, $assunto, $mensagem, $ishtml);
}
