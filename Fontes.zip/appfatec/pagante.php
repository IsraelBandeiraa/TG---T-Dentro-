<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

function isPagante($con,$idUser,$idEvento)
{
    $pagante = 0;

    if(($idUser === null) || ($idUser === "")){
        return $pagante;
    }
    if(($idEvento === null) || ($idEvento === "")){
        return $pagante;
    }
    
    //Busca o perfil do evento para saber se é pagante.
    $sql = "SELECT perfil,perfilConfig FROM evento e WHERE id = '$idEvento'";
    //echo $sql."\n";
    $consulta =  mysqli_query($con,$sql);
    if($resultado = mysqli_fetch_assoc($consulta)){
        $perfil = $resultado["perfil"];
        //echo "perfil: $perfil\n";
        if($perfil == "NAOPAGA"){ //Ninguem paga
            $pagante = 0;

        }else if($perfil == "CONVIDADOPAGA"){ //Todos os convidados pagam no evento
            $sql2 = "SELECT lide,lidefuturo FROM pessoa p WHERE id = '$idUser'";
            //echo $sql2."\n";
            $consulta2 =  mysqli_query($con,$sql2);
            if($resultado2 = mysqli_fetch_assoc($consulta2)){
                if(($resultado2["lide"] == 0) && ($resultado2["lidefuturo"] == 0)){
                    $pagante = 1;
                }
            }

        }else if($perfil == "FUTUROPAGASEGUNDO"){ //Todos os convidados pagam no evento
            $sql2 = "SELECT lide,lidefuturo FROM pessoa p WHERE id = '$idUser'";
            //echo $sql2."\n";
            $consulta2 =  mysqli_query($con,$sql2);
            if($resultado2 = mysqli_fetch_assoc($consulta2)){
                //echo "lide: ".$resultado2["lide"]."\n";
                //echo "lidefuturo: ".$resultado2["lidefuturo"]."\n";
                if(($resultado2["lide"] == 0) && ($resultado2["lidefuturo"] == 0)){
                    $pagante = 0;
                }else if(($resultado2["lide"] == 1)){
                    $pagante = 0;
                }else{
                    //Busca se nos eventos anterioes ele esteve presente
                    $eventosAnteriores = str_replace(",","','",$resultado["perfilConfig"]);

                    $sql3 = "SELECT COUNT(*) AS presenca FROM checkin c WHERE c.idevento IN ('$eventosAnteriores') AND c.iduser = '$idUser' AND (c.checkin = 1 OR c.checkinmanual = 1)";
                    //echo $sql3."\n";
                    $consulta3 =  mysqli_query($con,$sql3);
                    if($resultado3 = mysqli_fetch_assoc($consulta3)){
                        //echo "presenca: ".$resultado3["presenca"]."\n";
                        if($resultado3["presenca"] > 0){
                            $pagante = 1;
                        }
                    }
        
                }
            }
            
        }
    }

    //echo "pagante: $pagante\n";
    
    return $pagante;
}

function temAcesso($con,$idUser,$idEvento)
{
    $acesso = 0;

    if(($idUser === null) || ($idUser === "")){
        return $acesso;
    }
    if(($idEvento === null) || ($idEvento === "")){
        return $acesso;
    }

    $usuariolide = 0;
    $usuariolidefuturo = 0;
    $sql2 = "SELECT lide,lidefuturo FROM pessoa p WHERE id = '$idUser'";
    //echo $sql2."\n";
    $consulta2 =  mysqli_query($con,$sql2);
    if($resultado2 = mysqli_fetch_assoc($consulta2)){
        $usuariolide = $resultado2["lide"];
        $usuariolidefuturo = $resultado2["lidefuturo"];
    }
    if(($usuariolide == 1) && ($usuariolidefuturo == 1)){
        $acesso = 1;
    }else{
        $sql = "SELECT lide,lidefuturo FROM evento e WHERE id = '$idEvento'";
        //echo $sql."\n";
        $consulta =  mysqli_query($con,$sql);
        if($resultado = mysqli_fetch_assoc($consulta)){
            $eventolide = $resultado["lide"];
            $eventolidefuturo = $resultado["lidefuturo"];
        }
        if(($eventolide == 1) && ($usuariolide == 1)){
            $acesso = 1;
        }else if(($eventolidefuturo == 1) && ($usuariolidefuturo == 1)){
            $acesso = 1;
        }
    }
    
    return $acesso;
}

?>