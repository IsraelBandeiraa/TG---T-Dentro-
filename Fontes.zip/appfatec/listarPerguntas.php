<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$_POST = json_decode(file_get_contents('php://input'), true);

$idEvento = $_POST["idEvento"];

include("conexao.php");

$query = "SELECT p.nome,c.* FROM chatevento c,pessoa p WHERE c.senderid = p.id AND c.idevento = $idEvento";
$sql= mysqli_query($con, $query);
$data = array();
while ($result =  mysqli_fetch_array($sql, MYSQLI_ASSOC))
{
	array_push($data, $result);
}

mysqli_close($con);

echo json_encode($data);

?>