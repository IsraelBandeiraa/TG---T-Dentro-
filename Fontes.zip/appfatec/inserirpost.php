<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$_POST = json_decode(file_get_contents('php://input'), true);

include "notificacao.php";
include "conexao.php";

$titulo = $_POST["titulo"];
$texto = $_POST["texto"];
$aprovado = $_POST["aprovado"];
$iduser = $_POST["iduser"];
$imagem = $_POST["imagem"];

$compara = "select count(id) as contar from post where titulo = '$titulo' and texto ='$texto'";
$contar = mysqli_query($con, $compara);
$sim = mysqli_fetch_assoc($contar);

if ($sim["contar"] == 0) {

    $sql = "INSERT INTO post (iduser, titulo, texto, imagem, data, aprovado) VALUES ('$iduser','$titulo','$texto', '$imagem', CURRENT_DATE, '$aprovado')";
    mysqli_query($con, $sql);

    $sql1 = "SELECT * FROM post WHERE id = LAST_INSERT_ID()";
    $consulta = mysqli_query($con, $sql1);
    $resultado = mysqli_fetch_assoc($consulta);

    enviarNotificacao($con, "NOVOFEED", $iduser, "", array('tituloFeed' => $titulo,'idFeed' => $resultado['id']));
}

mysqli_close($con);

?>