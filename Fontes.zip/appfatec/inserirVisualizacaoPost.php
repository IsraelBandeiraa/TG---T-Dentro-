<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$_POST = json_decode(file_get_contents('php://input'), true);
include("conexao.php");
   
    $iduser = $_POST["iduser"];
    $idpost = $_POST["idpost"];
   
    if($idpost > 0 && $iduser > 0){
    $compara = "select count(id) as contar from postNotificacao where iduser = '$iduser' and idpost ='$idpost'";
    $contar = mysqli_query($con, $compara);
    $sim = mysqli_fetch_assoc($contar);

    if($sim["contar"] == 0){
    
    $sql = "insert into postNotificacao (iduser, idpost) values ('$iduser','$idpost')";   
     
    mysqli_query($con, $sql);
    }
}

     mysqli_close($con);

?>