<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$_POST = json_decode(file_get_contents('php://input'), true);

include("imagem.php");

include("conexao.php");

$id = $_POST["id"];
$tabela = $_POST["tabela"];
$campo = $_POST["campo"];
$campoid = $_POST["campoid"];

mysqli_query($con, "SET CHARACTER SET 'utf8'");

if($id != ""){
    $id = "WHERE $campoid = '$id'";
}

$query = "SELECT * FROM $tabela $id";
$sql= mysqli_query($con, $query);
while ($resultado =  mysqli_fetch_array($sql, MYSQLI_ASSOC))
{
    $idAtual = $resultado[$campoid];

    echo "Verificando Registro ID: $idAtual";

    $imagem = $resultado[$campo];
    if(!(substr($imagem, 0, 10) == "data:image")){
        //Imagem já está salva no disco
        echo " - Imagem já está salva no disco!!! \n";
        continue;
    }

    $imagem = salvarImagemDisco($imagem,$idAtual,$tabela);

    echo " - Imagem no disco: $imagem";

    $sql1=  "UPDATE $tabela SET $campo = '$imagem' WHERE $campoid = '$idAtual' ";

    $consulta = mysqli_query($con, $sql1);
    if($consulta){
        echo " - Registro alterado com sucesso!!!";
    }else{
        echo " - ERRO ao alterar registro!!!";
    }

    echo "\n";

}

mysqli_close($con);

?>