<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$_POST = json_decode(file_get_contents('php://input'), true);
include("conexao.php");
$iduser =$_POST["iduser"];
$idevento = $_POST["idevento"];
$lat = $_POST["lat"];
$long = $_POST["long"];
$resposta ="";
mysqli_query($con, "SET CHARACTER SET 'utf8'"); 

$compara = "select count(id) as contar from localizacaoevento where idevento = $idevento and iduser= $iduser ";
$consulta =  mysqli_query($con,$compara);
$resultado = mysqli_fetch_assoc($consulta);

if($resultado["contar"] == 0) {
$sql =  "INSERT INTO localizacaoevento(idevento, iduser, lat, lon) values($idevento, $iduser, $lat, $long)";
mysqli_query($con, $sql);
$resposta = '{"success" : true, "message" : "inseriu"}';

}
else{

    $sql =  "update localizacaoevento set lat = '$lat', lon = '$long'  where idevento = $idevento and iduser= $iduser";
    mysqli_query($con, $sql);


    $resposta = '{"success" : true, "message" : "alterou"}';
    
}

echo $resposta;
mysqli_close($con);

?>
