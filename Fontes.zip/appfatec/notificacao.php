<?php

function enviarNotificacao($con, $tipo, $usuarioid, $eventoid, $arrayDados)
{

    $titulo = "";
    $mensagen = "";
    $sqlUsuarios = null;
    $idssend = array();
    $idusuarios = array();
    $idtokens = array();
    $objetoid = 0;

    if ($tipo == "BOASVINDAS") {

        $nome = "";
        $lide = "";
        $lidefuturo = "";
        $filiacao = "";
        $perfil = "";
        $sql = mysqli_query($con, "SELECT nome,lide,lidefuturo,perfil FROM pessoa WHERE id = $usuarioid ");
        if ($usuario = mysqli_fetch_array($sql, MYSQLI_ASSOC)) {
            $nome = $usuario['nome'];
            $lide = $usuario['lide'];
            $lidefuturo = $usuario['lidefuturo'];
            $perfil = $usuario['perfil'];
        }

        $sqlUsuarios = mysqli_query($con, "SELECT p.id,pt.id idtoken,pt.token,p.nome
        FROM pessoa p
        INNER JOIN pessoatoken pt ON p.id=pt.userid
        WHERE status=1
        UNION
        SELECT p.id,'' idtoken,'' token,p.nome
        FROM pessoa p
        WHERE p.id NOT IN (SELECT pt.userid FROM pessoatoken pt)
        AND status=1
        AND (lide=1 or lidefuturo=1)");
        if (($lide == 1) && ($lidefuturo = 1)) {
            $filiacao = "LIDE";
        } else if ($lide == 1) {
            $filiacao = "LIDE";
        } else if ($lidefuturo == 1) {
            $filiacao = "LIDE Futuro";
        }
        if ($perfil == "FILIADO") {
            $perfil = "filiado";
        } else if ($perfil == "HEAD") {
            $perfil = "head";
        }

        $titulo = "Novo $perfil $filiacao";
        $texto = "Seja bem-vindo $perfil $nome";
    } else if ($tipo == "NOVOBENEFICIO") {

        $sqlUsuarios = mysqli_query($con, "SELECT p.id,pt.id idtoken,pt.token,p.nome
        FROM pessoa p
        INNER JOIN pessoatoken pt ON p.id=pt.userid
        WHERE status=1
        AND perfil = 'FILIADO'
        UNION
        SELECT p.id,'' idtoken,'' token,p.nome
        FROM pessoa p
        WHERE p.id NOT IN (SELECT pt.userid FROM pessoatoken pt)
        AND status=1
        AND perfil = 'FILIADO'
        AND (lide=1 or lidefuturo=1)");

        $objetoid = $arrayDados['id'];
        $nome = $arrayDados['titulo'];
        $titulo = "Novo Beneficio";
        $texto = "Parceria $nome, acesse agora e confira!";
    } else if ($tipo == "NOVOQUIZ") {

        $sqlUsuarios = mysqli_query($con, "SELECT p.id,pt.id idtoken,pt.token,p.nome
        FROM pessoa p
        INNER JOIN pessoatoken pt ON p.id=pt.userid
        WHERE status=1
        AND perfil = 'FILIADO'
        UNION
        SELECT p.id,'' idtoken,'' token,p.nome
        FROM pessoa p
        WHERE p.id NOT IN (SELECT pt.userid FROM pessoatoken pt)
        AND status=1
        AND perfil = 'FILIADO'
        AND (lide=1 or lidefuturo=1)");

        $objetoid = $arrayDados['id'];
        $nome = $arrayDados['titulo'];
        $titulo = "Novo Quiz";
        $texto = "$nome liberado, acesse agora e responda!";
    } else if ($tipo == "NOVOFEED") {

        $nome = "";
        $lide = "";
        $lidefuturo = "";
        $filiacao = "";
        $sql = mysqli_query($con, "SELECT nome,lide,lidefuturo FROM pessoa WHERE id = $usuarioid ");
        if ($usuario = mysqli_fetch_array($sql, MYSQLI_ASSOC)) {
            $nome = $usuario['nome'];
            $lide = $usuario['lide'];
            $lidefuturo = $usuario['lidefuturo'];
        }

        $sqlUsuarios = mysqli_query($con, "SELECT p.id,pt.id idtoken,pt.token,p.nome
        FROM pessoa p
        INNER JOIN pessoatoken pt ON p.id=pt.userid
        WHERE status=1
        AND perfil = 'FILIADO'
        UNION
        SELECT p.id,'' idtoken,'' token,p.nome
        FROM pessoa p
        WHERE p.id NOT IN (SELECT pt.userid FROM pessoatoken pt)
        AND status=1
        AND perfil = 'FILIADO'
        AND (lide=1 or lidefuturo=1)");

        $objetoid = $arrayDados['idFeed'];
        $tituloFeed = $arrayDados['tituloFeed'];
        $titulo = "Novo Compartilhe seu Sucesso";
        $texto = "$nome publicou $tituloFeed";
    } else if ($tipo == "ALTERACAOEVENTO") {

        $nome = "";
        $lide = "";
        $lidefuturo = "";
        $filiacao = "";
        $sql = mysqli_query($con, "SELECT nome,lide,lidefuturo FROM evento WHERE id = $eventoid");
        if ($usuario = mysqli_fetch_array($sql, MYSQLI_ASSOC)) {
            $nome = $usuario['nome'];
            $lide = $usuario['lide'];
            $lidefuturo = $usuario['lidefuturo'];
        }

        $sqlUsuarios = mysqli_query($con, "SELECT p.id,pt.id idtoken,pt.token,p.nome
        FROM pessoa p
        INNER JOIN pessoatoken pt ON p.id=pt.userid
        WHERE status=1
        AND perfil = 'FILIADO'
        UNION
        SELECT p.id,'' idtoken,'' token,p.nome
        FROM pessoa p
        WHERE p.id NOT IN (SELECT pt.userid FROM pessoatoken pt)
        AND status=1
        AND perfil = 'FILIADO'
        AND (lide=1 or lidefuturo=1)");
        if (($lide == 1) && ($lidefuturo = 1)) {
            $filiacao = "LIDE";
        } else if ($lide == 1) {
            $filiacao = "LIDE";
        } else if ($lidefuturo == 1) {
            $filiacao = "LIDE Futuro";
        }

        $objetoid = $eventoid;
        $titulo = "Evento $filiacao Alterado";
        $texto = "$nome foi alterado, acesse agora e veja as novidades";
    } else if ($tipo == "NOVOEVENTO") {

        $nome = "";
        $lide = "";
        $lidefuturo = "";
        $filiacao = "";
        $sql = mysqli_query($con, "SELECT nome,lide,lidefuturo FROM evento WHERE id = $eventoid");
        if ($usuario = mysqli_fetch_array($sql, MYSQLI_ASSOC)) {
            $nome = $usuario['nome'];
            $lide = $usuario['lide'];
            $lidefuturo = $usuario['lidefuturo'];
        }

        $sqlUsuarios = mysqli_query($con, "SELECT p.id,pt.id idtoken,pt.token,p.nome
        FROM pessoa p
        INNER JOIN pessoatoken pt ON p.id=pt.userid
        WHERE status=1
        AND perfil = 'FILIADO'
        UNION
        SELECT p.id,'' idtoken,'' token,p.nome
        FROM pessoa p
        WHERE p.id NOT IN (SELECT pt.userid FROM pessoatoken pt)
        AND status=1
        AND perfil = 'FILIADO'
        AND (lide=1 or lidefuturo=1)");
        if (($lide == 1) && ($lidefuturo = 1)) {
            $filiacao = "LIDE";
        } else if ($lide == 1) {
            $filiacao = "LIDE";
        } else if ($lidefuturo == 1) {
            $filiacao = "LIDE Futuro";
        }

        $objetoid = $eventoid;
        $titulo = "Novo Evento $filiacao";
        $texto = "$nome foi publicado, acesse agora e confirme sua presen�a!";
    } else if ($tipo == "AVALIAREVENTO") {

        $nome = "";
        $lide = "";
        $lidefuturo = "";
        $filiacao = "";
        $sql = mysqli_query($con, "SELECT nome,lide,lidefuturo FROM evento WHERE id = $eventoid");
        if ($usuario = mysqli_fetch_array($sql, MYSQLI_ASSOC)) {
            $nome = $usuario['nome'];
            $lide = $usuario['lide'];
            $lidefuturo = $usuario['lidefuturo'];
        }

        $sqlUsuarios = mysqli_query($con, "SELECT p.id,pt.id idtoken,pt.token,p.nome FROM checkin ch
            INNER JOIN evento ev ON ev.id = ch.idevento
            INNER JOIN pessoa p ON p.id = iduser
            LEFT JOIN pessoatoken pt ON p.id = pt.userid
            WHERE p.status=1 AND perfil = 'FILIADO' AND p.teste=1 AND (ch.checkin = 1) AND ev.id = $eventoid;");
        if (($lide == 1) && ($lidefuturo = 1)) {
            $filiacao = "LIDE";
        } else if ($lide == 1) {
            $filiacao = "LIDE";
        } else if ($lidefuturo == 1) {
            $filiacao = "LIDE Futuro";
        }

        $objetoid = $eventoid;
        $titulo = "Obrigado pela presen�a";
        $texto = "Obrigado pela presen�a no evento $nome, clique e deixe sua avalia��o";
    } else if ($tipo == "NOVOCHAT") {

        $nome = "";
        $lide = "";
        $lidefuturo = "";
        $filiacao = "";
        $sql = mysqli_query($con, "SELECT nome,lide,lidefuturo FROM pessoa WHERE id = '$usuarioid' ");
        if ($usuario = mysqli_fetch_array($sql, MYSQLI_ASSOC)) {
            $nome = $usuario['nome'];
            $lide = $usuario['lide'];
            $lidefuturo = $usuario['lidefuturo'];
        }

        $objetoid = $usuarioid;
        $receiverid = $arrayDados['receiverid'];
        $sqlUsuarios = mysqli_query($con, "SELECT id,token,nome FROM pessoa WHERE  id = '$receiverid'");

        $mensagem = $arrayDados['mensagem'];
        $titulo = "Chat de $nome";
        $texto = "$mensagem";
    } else if ($tipo == "NOVOCONTATO") {

        $nome = "";
        $lide = "";
        $lidefuturo = "";
        $filiacao = "";
        $sql = mysqli_query($con, "SELECT nome,lide,lidefuturo FROM pessoa WHERE id = $usuarioid ");
        if ($usuario = mysqli_fetch_array($sql, MYSQLI_ASSOC)) {
            $nome = $usuario['nome'];
            $lide = $usuario['lide'];
            $lidefuturo = $usuario['lidefuturo'];
        }

        $receiverid = $arrayDados['receiverid'];
        $sqlUsuarios = mysqli_query($con, "SELECT id,token,nome FROM pessoa WHERE  id = $receiverid");

        $objetoid = $usuarioid;
        $titulo = "Novo contato";
        $texto = "$nome adicionou voc� em sua rede.";
    } else if ($tipo == "APROVACAOCONTATO") {

        $nome = "";
        $lide = "";
        $lidefuturo = "";
        $filiacao = "";
        $sql = mysqli_query($con, "SELECT nome,lide,lidefuturo FROM pessoa WHERE id = $usuarioid ");
        if ($usuario = mysqli_fetch_array($sql, MYSQLI_ASSOC)) {
            $nome = $usuario['nome'];
            $lide = $usuario['lide'];
            $lidefuturo = $usuario['lidefuturo'];
        }

        $receiverid = $arrayDados['receiverid'];
        $sqlUsuarios = mysqli_query($con, "SELECT id,token,nome FROM pessoa WHERE  id = $receiverid");

        $titulo = "Confirma��o contato";
        $texto = "$nome confirmou sua solicita��o de contato";
    } else if ($tipo == "PERSONALIZADA") {

        $destinatario = $arrayDados["destinatario"];
        $titulo = $arrayDados["titulo"];
        $texto = $arrayDados["texto"];

        if ($destinatario == "TODOS") {
            $sqlUsuarios = mysqli_query($con, "SELECT p.id,pt.id idtoken,pt.token,p.nome
            FROM pessoa p
            INNER JOIN pessoatoken pt ON p.id=pt.userid
            WHERE status=1
            AND perfil = 'FILIADO'
            UNION
            SELECT p.id,'' idtoken,'' token,p.nome
            FROM pessoa p
            WHERE p.id NOT IN (SELECT pt.userid FROM pessoatoken pt)
            AND status=1
            AND perfil = 'FILIADO'
            AND (lide=1 or lidefuturo=1)");
        } else if ($destinatario == "LIDE") {
            $sqlUsuarios = mysqli_query($con, "SELECT p.id,pt.id idtoken,pt.token,p.nome
            FROM pessoa p
            INNER JOIN pessoatoken pt ON p.id=pt.userid
            WHERE status=1
            AND perfil = 'FILIADO'
            AND lide=1
            UNION
            SELECT p.id,'' idtoken,'' token,p.nome
            FROM pessoa p
            WHERE p.id NOT IN (SELECT pt.userid FROM pessoatoken pt)
            AND status=1
            AND perfil = 'FILIADO'
            AND lide=1");
        } else if ($destinatario == "LIDEFUTUTO") {
            $sqlUsuarios = mysqli_query($con, "SELECT p.id,pt.id idtoken,pt.token,p.nome
            FROM pessoa p
            INNER JOIN pessoatoken pt ON p.id=pt.userid
            WHERE status=1
            AND perfil = 'FILIADO'
            AND lidefuturo=1
            UNION
            SELECT p.id,'' idtoken,'' token,p.nome
            FROM pessoa p
            WHERE p.id NOT IN (SELECT pt.userid FROM pessoatoken pt)
            AND status=1
            AND perfil = 'FILIADO'
            AND lidefuturo=1");
        } else if ($destinatario == "TESTE") {
            $sqlUsuarios = mysqli_query($con, "SELECT p.id,pt.id idtoken,pt.token,p.nome
            FROM pessoa p
            INNER JOIN pessoatoken pt ON p.id=pt.userid
            WHERE status=1
            AND perfil = 'FILIADO'
            AND teste=1
            UNION
            SELECT p.id,'' idtoken,'' token,p.nome
            FROM pessoa p
            WHERE p.id NOT IN (SELECT pt.userid FROM pessoatoken pt)
            AND status=1
            AND perfil = 'FILIADO'
            AND teste=1");
        } else {
            $where = "";
            $checkin = $_POST['checkin'];
            $confirmar = $_POST['confirmar'];
            if (($checkin == "1") && ($confirmar == "1")) {
                $where = "AND (ch.checkin = 1 OR ch.confirmar = 1)";
            } else if ($checkin == "1") {
                $where = "AND (ch.checkin = 1)";
            } else if ($confirmar == "1") {
                $where = "AND (ch.confirmar = 1)";
            }
            $sqlUsuarios = mysqli_query($con, "SELECT p.id,pt.id idtoken,pt.token,p.nome FROM checkin ch
            INNER JOIN evento ev ON ev.id = ch.idevento
            INNER JOIN pessoa p ON p.id = iduser
            LEFT JOIN pessoatoken pt ON p.id = pt.userid
            WHERE p.status=1 $where AND perfil = 'FILIADO' AND ev.id = $destinatario;");
        }
    }

    if ($sqlUsuarios != null) {
        while ($usuario = mysqli_fetch_array($sqlUsuarios, MYSQLI_ASSOC)) {
            if ($usuario['token'] != "") {
                array_push($idssend, $usuario['token']);
                $idtokens[$usuario['token']] = $usuario['id'];
            }
            $idusuarios[$usuario['id']] = array(
                "token" => $usuario['token'],
                "nome" => $usuario['nome'],
                "status" => "",
                "entregue" => 0,
            );
        }
    }

    $retorno = enviarPush($con, $idssend, $titulo, $texto, $tipo, $idusuarios, $objetoid, $idtokens);

    return $retorno;
}

function enviarPush($con, $idssend, $titulo, $texto, $tipo, $idusuarios, $objetoid, $idtokens)
{

    if (count($idssend) > 0) {
        $offset = 0;
        $length = 900;
        $retorno = array();
        while (true) {
            $lenviar = array_slice($idssend, $offset, $length);
            if (count($lenviar) > 0) {
                $json = enviaFCM($con, $lenviar, $titulo, $texto, $tipo, $idusuarios, $objetoid, $idtokens);
                array_push($retorno, $json);
            } else {
                break;
            }
            $offset = $offset + $length;
        }
        $retorno = array('success' => true, 'dados' => $retorno);
    } else {
        $retorno = array('success' => false, 'message' => 'N�o foi identificado nenhum usu�rio para envio');
    }

    return $retorno;
}

function enviaFCM($con, $idssend, $titulo, $texto, $tipo, $idusuarios, $objetoid, $idtokens)
{
    $url = 'https://fcm.googleapis.com/fcm/send';

    $fields = array(
        'registration_ids' => $idssend,
        'notification' => array(
            "title" => $titulo,
            "body" => $texto,
            "click_action" => $tipo,
        ),
        'data' => array(
            "title" => $titulo,
            "body" => $texto,
            "tipo" => $tipo,
            "objetoid" => $objetoid,
        ),
    );
    $json = json_encode($fields);

    //alterar a key
    $headers = array(
        'Authorization: key=' . "AAAAW34Ur8I:APA91bFeB34Td7RO_jSgkvg1iPR4Bn3K_Q3-DMA588ax0N4rgXflwGyY-nASepid4oIEU-pCEwqe5XVXoDMxlLGNgDqFXw2Omnhbp6dIgAT7EfP0SWhG1QVCywljamfPKxJuSwKip2RJ",
        'Content-Type: application/json',
    );

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $json);

    $result = curl_exec($ch);

    curl_close($ch);

    $fields['registration_ids'] = "";
    $json = addslashes(json_encode($fields));

    $jsonRet = json_decode($result, true);

    //Salvando os dados de notifica��es
    $sql = "INSERT INTO notificacao (jsoncorpo,tipo,datahora,objetoid) VALUES ('$json','$tipo',NOW(),'$objetoid')";

    $consulta = mysqli_query($con, $sql);
    if ($consulta) {
        $sql1 = "SELECT * FROM notificacao WHERE id = LAST_INSERT_ID()";
        $consulta = mysqli_query($con, $sql1);
        $resultado = mysqli_fetch_assoc($consulta);
        $notificaocaoid = $resultado['id'];
        $arrayResults = $jsonRet['results'];
        $arrayDados = array();

        foreach ($arrayResults as $indice => $valor) {
            $userid = $idtokens[$idssend[$indice]];
            $entregue = array_key_exists('message_id', $valor) ? 1 : 0;
            $status = ($entregue) ? '' : $valor['error'];
            $idusuarios[$userid]["status"] = $idusuarios[$userid]["status"] . $status . " - ";
            $idusuarios[$userid]["entregue"] = ($idusuarios[$userid]["entregue"]) ? 1 : $entregue;
        }
        foreach ($idusuarios as $indice => $valor) {
            $userid = $indice;
            $entregue = $idusuarios[$userid]["entregue"];
            $status = $idusuarios[$userid]["status"];

            array_push($arrayDados, "('$notificaocaoid','$userid','$tipo',$entregue,'$status',0,'$objetoid')");
        }
        $dados = join(',', $arrayDados);

        $sql = "INSERT INTO notificacaousuario (notificacaoid,userid,tipo,entregue,status,lido,objetoid) VALUES $dados";
        $consulta = mysqli_query($con, $sql);
        if ($consulta) {
        } else {
            $name = "zlog_falha_notifica.txt";
            $text = "Erro ao salvar usuarios: $sql - $consulta\n";
            $file = fopen($name, 'a');
            fwrite($file, $text);
            fclose($file);
        }
    } else {
        $name = "zlog_falha_notifica.txt";
        $text = "Erro ao salvar dados: $sql - $consulta\n";
        $file = fopen($name, 'a');
        fwrite($file, $text);
        fclose($file);
    }

    return $result;
}

function enviarEmail($remetente, $destinatarios, $assunto, $mensagem, $ishtml)
{
    require_once('PHPMailerAutoload.php');

    $mail = new PHPMailer();

    $mail->IsSMTP();
    $mail->Host = "smtp.clientestotvssm.com.br";
    $mail->SMTPAuth = true;
    $mail->Port = 587;
    $mail->SMTPSecure = false;
    $mail->SMTPAutoTLS = false;
    $mail->Username = 'no.reply@clientestotvssm.com.br';
    $mail->Password = '12TSMZ8Ei';

    // $mail->IsSMTP();
    // $mail->Host = "smtp.gmail.com";
    // $mail->SMTPAuth = true;
    // $mail->Port = 587;
    // $mail->SMTPSecure = false;
    // $mail->SMTPAutoTLS = false;
    // $mail->Username = 'no.replytodentro@gmail.com';
    // $mail->Password = '!Senha@2023!';


    // DADOS DO REMETENTE
    $mail->Sender = "nno.reply@clientestotvssm.com.br"; // Conta de email existente e ativa em seu dom�nio
    $mail->From = "no.reply@clientestotvssm.com.br"; // Sua conta de email que ser� remetente da mensagem
    $mail->FromName = "Equipe Tô Dentro!"; // Nome da conta de email  
    if ($remetente) {
        if ($remetente['email']) {
            $mail->From = $remetente['no.reply@clientestotvssm.com.br']; // Sua conta de email que ser� remetente da mensagem
        }
        if ($remetente['nome']) {
            $mail->FromName = $remetente['Equipe Tô Dentro!']; // Nome da conta de email
        }
    }

    // DADOS DO DESTINATÁRIO
    foreach ($destinatarios as $destinatario) {
        $nome = '';
        if ($destinatario['nome']) {
            $nome = $destinatario['nome'];
        }
        if ($destinatario['tipo'] == "cc") {
            $mail->addCC('' . $destinatario['email'] . '', $nome);
        } else if ($destinatario['tipo'] == "cco") {
            $mail->addBCC('' . $destinatario['email'] . '', $nome);
        } else if ($destinatario['tipo'] == "reply") {
            $mail->addReplyTo('' . $destinatario['email'] . '', $nome);
        } else {
            $mail->AddAddress('' . $destinatario['email'] . '', $nome);
        }
    }

    // Defini��o de HTML/codifica��o
    $mail->IsHTML($ishtml);
    $mail->CharSet = 'utf-8';

    // DEFINI��O DA MENSAGEM
    $mail->Subject = $assunto;
    $mail->Body = $mensagem;

    // ENVIO DO EMAIL
    $enviado = $mail->Send();

    // Limpa os destinat�rios e os anexos
    $mail->ClearAllRecipients();

    return $enviado;
}
