<?php
header("Access-Control-Allow-Origin: *");
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

include "imagem.php";

include "conexao.php";

$_POST = json_decode(file_get_contents('php://input'), true);
$eventoid = $_POST["eventoid"];
$filiadoid = $_POST["filiadoid"];

$sql = "SELECT * FROM evento WHERE id = '$eventoid'";
mysqli_query($con, "SET CHARACTER SET 'utf8'");
$consulta = mysqli_query($con, $sql);

$data = array();
if ($result = mysqli_fetch_array($consulta, MYSQLI_ASSOC)) {

    $sql2 = "SELECT * FROM posevento WHERE eventoid = $eventoid ORDER BY ordem";
    $consulta2 = mysqli_query($con, $sql2);
    $datapos = array();
    while ($result2 = mysqli_fetch_array($consulta2, MYSQLI_ASSOC)) {
        $imagem = $result2['imagem'];
        if (($imagem != '') && (!(substr($imagem, 0, 10) == "data:image"))) {
            $imagem = $url . $imagem;
        }
        $poster = $result2['poster'];
        if (($poster != '') && (!(substr($poster, 0, 10) == "data:image"))) {
            $poster = $url . $poster;
        }

        $video = $result2['video'];
        if ($video != "") {
            $video = $url . $result2['video'];
        }

        array_push($datapos, array(
            'ordem' => $result2['ordem'],
            'id' => $result2['id'],
            'video' => $video,
            'type' => $result2['type'],
            'poster' => $poster,
            'imagem' => $imagem,
            'texto' => $result2['texto'],
            'youtube' => $result2['youtube']
        ));
    }

    $sql = "SELECT p.lide, 
                p.lidefuturo, 
                p.lidemulher,
                c.confirmar
            FROM pessoa AS p
            LEFT JOIN checkin AS c ON p.id = c.iduser AND c.idevento = $eventoid
            WHERE p.id = $filiadoid";
    $consultaFiliado =  mysqli_query($con, $sql);
    $resultFiliado = mysqli_fetch_assoc($consultaFiliado);

    $confirmados = 0;
    $sqlConf = "SELECT COUNT(*) confirmados FROM checkin WHERE idevento = '$eventoid' AND confirmar = 1";
    $consultaConf = mysqli_query($con, $sqlConf);
    if ($resultadoConf = mysqli_fetch_assoc($consultaConf)) {
        $confirmados = $resultadoConf["confirmados"];
    }
    $vagasDisponiveis = $result['vagas'] - $confirmados;

    $date = $result['data'] . ' ' . $result['hora'];
    $data_evento = strtotime($date);
    // $timestamp = strtotime('+1 hour', $timestamp);
    $data_atual = time();

    $podeConfirmar = false;
    if ($data_atual <= $data_evento) {
        if (($result['lide'] == 1) && ($result['lide'] == $resultFiliado['lide'])) {
            $podeConfirmar = true;
        }
        if (($result['lidefuturo'] == 1) && ($result['lidefuturo'] == $resultFiliado['lidefuturo'])) {
            $podeConfirmar = true;
        }
        if (($result['lidemulher'] == 1) && ($result['lidemulher'] == $resultFiliado['lidemulher'])) {
            $podeConfirmar = true;
        }
        if (($result['vagas'] > 0) && ($vagasDisponiveis == 0) && ($resultFiliado['confirmar'] == null)) {
            $podeConfirmar = false;
        }
    }

    $data = array(
        'data' => $result['data'],
        'descricao' => preg_replace("/<\s*style.+?<\s*\/\s*style.*?>/s", "", $result['descricao']),
        'endereco' => $result['endereco'],
        'funcao' => $result['funcao'],
        'hora' => $result['hora'],
        'id' => $result['id'],
        'imagem' => $result['imagem'],
        'latitude' => $result['latitude'],
        'longitude' => $result['longitude'],
        'lide' => $result['lide'],
        'lidefuturo' => $result['lidefuturo'],
        'lidemulher' => $result['lidemulher'],
        'link' => $result['link'],
        'local' => $result['local'],
        'nome' => $result['nome'],
        'organizador' => $result['organizador'],
        'paleestrante' => $result['palestrante'],
        'status' => $result['status'],
        'vagas' => $result['vagas'],
        'vagasDisponiveis' => $vagasDisponiveis,
        'posevento' => $datapos,
        'podeConfirmar' => $podeConfirmar,
        'confirmar' => $resultFiliado['confirmar']
    );
}

echo json_encode($data);

mysqli_close($con);
