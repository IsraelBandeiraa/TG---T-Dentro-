<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$_POST = json_decode(file_get_contents('php://input'), true);
include("conexao.php");
$id = $_POST["id"];
$valor = $_POST["valor"];
$user = $_POST["user"];
$contador = count($id);
$contar = 0;
// $contar  = 0
 for ($i=0; $i < $contador ; $i++) { 

    $compara = "select count(id) as contar from quizresposta where idpergunta = ".$id[$i]." and idusuario ='$user'";

    $consulta =  mysqli_query($con,$compara);
    $resultado = mysqli_fetch_assoc($consulta);
   if($resultado["contar"] == 0)
   {
        $sql = "insert into quizresposta (idpergunta,idusuario,resposta) values(".$id[$i].", '$user', '".$valor[$i]."')";     
        mysqli_query($con, $sql);
   }
   else{

        $contar++;
   }

       
 }

 if($contar == 0)
 {
     $resposta = '{"success": true, "message" : "Quiz Respondido com Sucesso!"}';
 }

  else{
      $resposta = '{"success": false, "message" : "Você já respondeu este Quiz!"}';
  }


  
    echo $resposta;
    mysqli_close($con);

?>
