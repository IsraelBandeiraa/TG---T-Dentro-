<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

include("imagem.php");
include("conexao.php");
   
mysqli_query($con, "SET NAMES 'utf8'"); 
mysqli_query($con, "SET CHARACTER SET 'utf8'"); 
$query = "SELECT * FROM promocao";
$sql= mysqli_query($con, $query);
$data = array();
while ($result =  mysqli_fetch_array($sql, MYSQLI_ASSOC))
{

	$foto = $result['foto'];
	if (($foto != '') && (!(substr($foto, 0, 10) == "data:image"))) {
		$result['foto'] = $url . $foto;
	}

	array_push($data, $result);
}

mysqli_close($con);

echo json_encode($data);
