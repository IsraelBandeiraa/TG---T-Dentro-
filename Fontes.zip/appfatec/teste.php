<?php 

	$user 		= trim($_REQUEST['user']);
	$password 	= trim($_REQUEST['password']);
	$company 	= trim($_REQUEST['company']);
	$operation	= trim($_REQUEST['operation']);
	$input_xml 	= trim($_REQUEST['input_xml']);

	$wsdl_file 	= trim($_REQUEST['wsdl_file']);
	$wsdl_file = explode('.', end(explode('/', $wsdl_file)));
	$wsdl_file = $wsdl_file[0];
	
echo $input_xml;
