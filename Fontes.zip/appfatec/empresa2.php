<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("conexao.php");
   
mysqli_query($con, "SET NAMES 'utf8'"); 
mysqli_query($con, "SET CHARACTER SET 'utf8'"); 
$id = $_GET["id"];
$query = "select * from empresa where lidefuturo = 1 and id > '$id'";
$sql= mysqli_query($con, $query);
$data = array();

while ($result =  mysqli_fetch_array($sql, MYSQLI_ASSOC))
{
array_push($data, array('id' => $result['id'], 
	'nome' => $result['nome'], 
	'foto' => $result['foto'],
	 'endereco' => $result['endereco'], 
	 'site' => $result['site'],
	 'tel' => $result['tel'],
     'status' => $result['status'],
	 'segmento' => $result['segmento'],
	 'lide' => $result["lide"],
	 'lidefuturo' =>$result["lidefuturo"],
	));

}
echo json_encode($data);


mysqli_close($con);

?>