<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("imagem.php");
include("conexao.php");

$_POST = json_decode(file_get_contents('php://input'), true);
mysqli_query($con, "SET NAMES 'utf8'"); 
mysqli_query($con, "SET CHARACTER SET 'utf8'");

// $inicio = $_POST["inicio"];
// $fim = $_POST["fim"];

$pagina = $_GET["pagina"];
$user = $_GET["user"];
	$numreg = 3; // Quantos registros por página vai ser mostrado
	if (!isset($pagina)) {
		$pagina = 0;
	}
	$inicial = $pagina * $numreg;

    if($user > 0){
        $query = "select pessoa.id,pessoa.nome as nome, pessoa.imagem as foto, post.data, post.titulo, post.texto, post.imagem as imagem, post.id as postid, 
        COALESCE((SELECT count(id) FROM postcurtida where postcurtida.idpost = post.id),0) as curtiu, 
        COALESCE((SELECT count(id) FROM postcurtida where postcurtida.idpost = post.id and iduser = $user and curtiu = 1),0) as eucurti
        from post JOIN pessoa on pessoa.id = post.iduser where post.aprovado = 1 order by post.id desc LIMIT $inicial, $numreg "; 
        
         //limit $inicio, $fim
        $sql= mysqli_query($con, $query);
        $data = array();
        while ($result =  mysqli_fetch_array($sql, MYSQLI_ASSOC))
        {
          $imagem = $result['imagem'];
          if (($imagem != '') && (!(substr($imagem, 0, 10) == "data:image"))) {
              $imagem = $url . $imagem;
          }
          $foto = $result['foto'];
          if (($foto != '') && (!(substr($foto, 0, 10) == "data:image"))) {
              $foto = $url . $foto;
          }
            array_push($data, array(
                'id' => $result['id'], 
                'nome' => $result['nome'], 
                'foto' => $foto, 
                'data' => $result['data'],
                'titulo' => $result['titulo'],
                'texto' => $result['texto'],
                'empresa' => $result['empresa'],
                'imagem' => $imagem,
                'postid' => $result['postid'],
                'curtiu' => $result["curtiu"],
                'eucurti' => $result["eucurti"]
            ));
        }
        
echo json_encode($data);
    }
mysqli_close($con);

?>
