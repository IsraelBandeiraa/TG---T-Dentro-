<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("conexao.php");
   
mysqli_query($con, "SET NAMES 'utf8'"); 
mysqli_query($con, "SET CHARACTER SET 'utf8'"); 
$query = "select count(id) as contar from empresa where lidefuturo = 1 ";
$sql= mysqli_query($con, $query);
$data = mysqli_fetch_assoc($sql);


echo json_encode($data);


mysqli_close($con);

?>