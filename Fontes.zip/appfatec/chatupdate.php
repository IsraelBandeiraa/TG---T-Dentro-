<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("conexao.php");

$_POST = json_decode(file_get_contents('php://input'), true);
mysqli_query($con, "SET NAMES 'utf8'"); 
mysqli_query($con, "SET CHARACTER SET 'utf8'");
$receiverid = $_POST["receiverid"];
$senderid = $_POST["senderid"];
$vida = "UPDATE chat SET lido = 1 where receverid = '$senderid' and senderid = '$receiverid' and lido = 0";
$teste = mysqli_query($con, $vida);
mysqli_close($con);

?>