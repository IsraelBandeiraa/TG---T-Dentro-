<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$_POST = json_decode(file_get_contents('php://input'), true);

$listaid = $_POST["listaid"];

include "conexao.php";

$sql = "UPDATE notificacaousuario SET lido = 1 WHERE id IN ($listaid)";
$consulta = mysqli_query($con, $sql);
if ($consulta) {
    $retorno = array('success' => true, 'message' => 'Notificações marcadas como lida.');
} else {
    $retorno = array('success' => false, 'message' => 'Erro ao marcar notificações como lida. #1');
}
echo json_encode($retorno);

mysqli_close($con);

?>