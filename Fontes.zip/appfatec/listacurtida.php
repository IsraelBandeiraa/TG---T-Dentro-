<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("conexao.php");

$_POST = json_decode(file_get_contents('php://input'), true);

$id = $_POST["id"];
$query = "SELECT pessoa.id, pessoa.nome, pessoa.email, pessoa.cpf,
pessoa.cargo, pessoa.empresa,pessoa.lide, pessoa.lidefuturo, pessoa.compTel,
pessoa.compTelSec,pessoa.compEmail,pessoa.compEmailSec,pessoa.emailSec,
pessoa.tel, pessoa.telSec, pessoa.imagem, pessoa.nascimento, pessoa.segmento
 FROM postcurtida INNER join pessoa on pessoa.id = postcurtida.iduser
  where idpost ='$id' ";
$sql= mysqli_query($con, $query);
$data = array();
while ($result =  mysqli_fetch_array($sql, MYSQLI_ASSOC))
{

    array_push($data, array(
        'id' => $result['id'], 
        'nome' => $result['nome'], 
        'email' => $result['email'],
        'cpf' => $result['cpf'],
        'cargo' => $result['cargo'],
        'empresa' => $result['empresa'],
        'lide' => $result['lide'],
        'lidefuturo' => $result['lidefuturo'],
        'compTel' => $result['compTel'],
        'compTelSec' => $result['compTelSec'],
        'compEmail' => $result['compEmail'],
        'compEmailSec' => $result['compEmailSec'],
        'emailSec' => $result['emailSec'],
        'tel' => $result['tel'],
        'telSec' => $result['telSec'],
        'imagem' => $result['imagem'],
        'nascimento' => $result['nascimento'],    
        'segmento' => $result['segmento'],

    ));
}

echo json_encode($data);
mysqli_close($con);

?>