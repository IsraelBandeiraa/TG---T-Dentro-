<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include "conexao.php";

$_POST = json_decode(file_get_contents('php://input'), true);
mysqli_query($con, "SET NAMES 'utf8'");

$quizzes = $_POST['quizzes'];
$idquizzes = str_replace(",", "','", $quizzes);

$quizrespondido = false;

$perguntas = array();

$query = "SELECT id,titulo,enviounico,editar FROM quiz WHERE id IN ('$idquizzes') ";
$sql = mysqli_query($con, $query);
$data = array();
while ($result = mysqli_fetch_array($sql, MYSQLI_ASSOC)) {
    $quizid = $result['id'];

    $queryP = "SELECT id,quizid,pergunta,tiporesposta,editar FROM quizpergunta WHERE quizid = '$quizid' ORDER BY ordem";
    $sqlP = mysqli_query($con, $queryP);
    while ($resultP = mysqli_fetch_array($sqlP, MYSQLI_ASSOC)) {
        $perguntaid = $resultP['id'];

        $respostas = array();

        if (($resultP['tiporesposta'] == "MULTIPLAESCOLHA") || ($resultP['tiporesposta'] == "UNICAESCOLHA")) {

            $queryA = "SELECT id,quizperguntaid,descricao FROM quizalternativa WHERE quizperguntaid = '$perguntaid' ORDER BY ordem";
            $sqlA = mysqli_query($con, $queryA);
            $alternativas = array();
            while ($resultA = mysqli_fetch_array($sqlA, MYSQLI_ASSOC)) {
                $alternativaid = $resultA['id'];

                $total = 0;
                $queryR = "SELECT COUNT(*) total FROM quizresposta WHERE quizperguntaid = '$perguntaid' AND resposta = '$alternativaid'";
                $sqlR = mysqli_query($con, $queryR);
                while ($resultR = mysqli_fetch_array($sqlR, MYSQLI_ASSOC)) {
                    $total = $resultR['total'];
                }

                array_push($respostas, array(
                    'descricao' => $resultA['descricao'],
                    'total' => $total,
                ));

            }

        } else if ($resultP['tiporesposta'] == "LIVRE") {

            $queryR = "SELECT resposta,nome FROM quizresposta qr, pessoa p WHERE qr.usuarioid = p.id AND quizperguntaid = '$perguntaid'";
            $sqlR = mysqli_query($con, $queryR);
            while ($resultR = mysqli_fetch_array($sqlR, MYSQLI_ASSOC)) {
                array_push($respostas, array(
                    'descricao' => $resultR["resposta"],
                    'nome' => $resultR["nome"]
                ));
            }

        } else if ($resultP['tiporesposta'] == "STAR") {

            $stars = array(
                'STAR' => '0',
                'STAR1' => '0',
                'STAR2' => '0',
                'STAR3' => '0',
                'STAR4' => '0',
                'STAR5' => '0',
            );

            $queryR = "SELECT resposta,COUNT(id) total FROM quizresposta WHERE quizperguntaid = '$perguntaid' GROUP BY resposta";
            $sqlR = mysqli_query($con, $queryR);
            while ($resultR = mysqli_fetch_array($sqlR, MYSQLI_ASSOC)) {
                $stars['STAR'.$resultR['resposta']] = $resultR['total'];
            }

            array_push($respostas, array(
                'descricao' => 'STAR',
                'total' => $stars["STAR"]
            ));
            array_push($respostas, array(
                'descricao' => 'STAR1',
                'total' => $stars["STAR1"]
            ));
            array_push($respostas, array(
                'descricao' => 'STAR2',
                'total' => $stars["STAR2"]
            ));
            array_push($respostas, array(
                'descricao' => 'STAR3',
                'total' => $stars["STAR3"]
            ));
            array_push($respostas, array(
                'descricao' => 'STAR4',
                'total' => $stars["STAR4"]
            ));
            array_push($respostas, array(
                'descricao' => 'STAR5',
                'total' => $stars["STAR5"]
            ));

        }

        array_push($perguntas, array(
            'titulo' => $result['titulo'],
            'id' => $resultP['id'],
            'quizid' => $resultP['quizid'],
            'pergunta' => $resultP['pergunta'],
            'tiporesposta' => $resultP['tiporesposta'],
            'respostas' => $respostas,
        ));

    }

}

echo json_encode($perguntas);

mysqli_close($con);

?>