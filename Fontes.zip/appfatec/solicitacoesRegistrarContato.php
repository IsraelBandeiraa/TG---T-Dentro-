<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("conexao.php");
include("imagem.php");

$_POST = json_decode(file_get_contents('php://input'), true);

$solicitacaoid = $_POST["solicitacaoid"];
$resposta = $_POST["resposta"];
$campo = $_POST["campo"];

$url = full_url($_SERVER);

$sql = "UPDATE solicitacao_compra SET $campo='$resposta' WHERE id = $solicitacaoid";
$consulta = mysqli_query($con, $sql);

mysqli_close($con);

$retorno = array(
    'success' => true
);
echo json_encode($retorno);
