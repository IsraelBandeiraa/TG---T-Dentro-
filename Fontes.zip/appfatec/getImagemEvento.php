<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

include("imagem.php");

include("conexao.php");

$_POST = json_decode(file_get_contents('php://input'), true);

$eventoid = $_POST["eventoid"];

if(($eventoid === null) || ($eventoid === "")){
    $retorno = array('success' => false,'message'=>'Evento não foi definido.');
    echo json_encode($retorno);
    return;
}

$url = full_url( $_SERVER );

$sql = "SELECT ei.* FROM eventoimagem ei WHERE ei.eventoid = $eventoid";
$consulta =  mysqli_query($con,$sql);
$data = array();
while ($result =  mysqli_fetch_array($consulta, MYSQLI_ASSOC))
{
    $imagem = $result['imagem'];
    if(!(substr($imagem, 0, 10) == "data:image")){
        $imagem = $url . $imagem;
    }

    array_push($data, array(
            'id' => $result['id'], 
        	'eventoid' => $result['eventoid'],
            'imagem' => $imagem, 
            'link' => $result['link']
    ));
}

mysqli_close($con);

$retorno = array('success' => true,'dados'=>$data);
echo json_encode($retorno);

?>