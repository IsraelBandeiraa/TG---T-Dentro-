<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include("conexao.php");
   
$_POST = json_decode(file_get_contents('php://input'), true);
$senderid = $_POST["senderid"];
$receiverid = $_POST["receiverid"];
$query = "SELECT DISTINCT * FROM chat where senderid = $senderid and receverid = $receiverid
UNION all select * from chat where senderid = $receiverid and receverid = $senderid order by id asc";
$sql= mysqli_query($con, $query);
$data = array();
while ($result =  mysqli_fetch_array($sql, MYSQLI_ASSOC))
{
array_push($data, array('id' => $result['id'], 
    'mensagem' => $result['mensagem'], 
    'senderid' => $result['senderid'],
    'receiverid' => $result['receiverid'],
	'data' => $result['data'],
	 'lido' => $result['lido'] 
	));

}
echo json_encode($data);


mysqli_close($con);

?>