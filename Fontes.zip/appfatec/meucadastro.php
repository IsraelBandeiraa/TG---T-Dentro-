<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$_POST = json_decode(file_get_contents('php://input'), true);
include("conexao.php");
       $id = $_POST["id"];
    $nome = $_POST["nome"];
    $email = $_POST["email"];
    $senha = $_POST["senha"];
    $cargo = $_POST["cargo"];
    $empresa = $_POST["empresa"];
    $lide =$_POST["lide"];
    $lidefuturo =$_POST["lidefuturo"];
    $compTel =$_POST["compTel"];
    $compTelSec	 =$_POST["compTelSec"];
    $compEmail =$_POST["compEmail"];
    $compEmailSec =$_POST["compEmailSec"];
    $emailSec =$_POST["emailSec"];
    $site = $_POST["site"];
    $tel =$_POST["tel"];
    $telSec =$_POST["telSec"];   
    $imagem =$_POST["imagem"];
    // $nascimento =$_POST["nascimento"];
    $segmento =$_POST["segmento"];
    $cpf = $_POST["cpf"];
    
    mysqli_query($con, "SET CHARACTER SET 'utf8'"); 

    $sql =  "UPDATE pessoa set nome = '$nome', email='$email', cpf='$cpf', senha = '$senha', cargo = '$cargo', empresa = '$empresa', lide = '$lide', 
    lidefuturo = '$lidefuturo', compEmail = '$compEmail', compTel='$compTel', compTelSec = '$compTelSec', compEmailSec = '$compEmailSec',
    emailSec = '$emailSec', site = '$site', tel = '$tel', telSec = '$telSec', imagem = '$imagem',  segmento = '$segmento',
    primeirologin = 1, modificado = 1
    where id = '$id'";
     mysqli_query($con, $sql);
     mysqli_close($con);

?>