<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$_POST = json_decode(file_get_contents('php://input'), true);

$iduser = $_POST["iduser"];
$id = $_POST["id"];

if(($id === null) || ($id === "")){
    $retorno = array('success' => false,'message'=>'ID não foi definido.');
    echo json_encode($retorno);
    return;
}

if(($iduser === null) || ($iduser === "")){
    $retorno = array('success' => false,'message'=>'Usuário não foi definido.');
    echo json_encode($retorno);
    return;
}

$lat = 0;
$long = 0;

include("conexao.php");

$retorno = array('success' => false,'message'=>'Erro não identificado.');

$sql = "UPDATE checkin SET confirmar = 0 WHERE iduser = $iduser and id = $id ";
$consulta = mysqli_query($con, $sql);
if($consulta){
    $retorno = array('success' => true,'message'=>'Confirmação removida com sucesso.');
}else{
    $retorno = array('success' => false,'message'=>'Erro ao remover a confirmação. #1');
}

mysqli_close($con);

echo json_encode($retorno);

?>